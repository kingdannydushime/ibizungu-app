import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Service de stockage local
/// Gère la persistance des données utilisateur et de l'historique
class StorageService extends ChangeNotifier {
  static const String _keyPseudo = 'user_pseudo';
  static const String _keyDdkBalance = 'ddk_balance';
  static const String _keyPlayerId = 'player_id';
  static const String _keyTheme = 'theme_mode';
  static const String _keyHistory = 'game_history';
  static const String _keyAdminCode = 'admin_code';

  late SharedPreferences _prefs;
  bool _isInitialized = false;

  /// Vérifie si le service est initialisé
  bool get isInitialized => _isInitialized;

  /// Méthode helper pour vérifier l'initialisation avant chaque accès
  /// Jette une exception si pas initialisé (pour debugging)
  void _ensureInitialized() {
    if (!_isInitialized) {
      debugPrint('⚠️ StorageService utilisé avant initialisation! '
          'Appelez init() d\'abord.');
      // Option 1: Jeter une exception (recommandé pour le développement)
      // throw StateError('StorageService non initialisé! Appelez init() dans main()');
      // Option 2: Silencieux (pour la production)
    }
  }

  /// Initialise le service
  Future<void> init() async {
    if (_isInitialized) return;
    _prefs = await SharedPreferences.getInstance();
    _isInitialized = true;
    debugPrint('✅ StorageService initialisé');
  }

  /// Sauvegarde le pseudo de l'utilisateur
  /// Le pseudo est verrouillé après la première configuration
  Future<void> savePseudo(String pseudo) async {
    _ensureInitialized();
    if (!_isInitialized) return; // Sécurité supplémentaire

    // Vérifie si le pseudo est déjà configuré (verrouillé)
    if (hasPseudo()) {
      return; // Pseudo verrouillé, ne peut plus être modifié
    }
    await _prefs.setString(_keyPseudo, pseudo);
    notifyListeners();
  }

  /// Récupère le pseudo de l'utilisateur
  String? getPseudo() {
    _ensureInitialized();
    if (!_isInitialized) return null;
    return _prefs.getString(_keyPseudo);
  }

  /// Vérifie si un pseudo a été configuré
  bool hasPseudo() {
    _ensureInitialized();
    if (!_isInitialized) return false;
    return _prefs.containsKey(_keyPseudo);
  }

  /// Sauvegarde le solde DDK
  Future<void> saveDdkBalance(int balance) async {
    _ensureInitialized();
    if (!_isInitialized) return;
    await _prefs.setInt(_keyDdkBalance, balance);
    notifyListeners();
  }

  /// Récupère le solde DDK
  int getDdkBalance() {
    _ensureInitialized();
    if (!_isInitialized) return 1000; // Valeur par défaut
    return _prefs.getInt(_keyDdkBalance) ?? 1000;
  }

  /// Sauvegarde l'ID du joueur
  Future<void> savePlayerId(String id) async {
    _ensureInitialized();
    if (!_isInitialized) return;
    await _prefs.setString(_keyPlayerId, id);
  }

  /// Récupère l'ID du joueur
  String? getPlayerId() {
    _ensureInitialized();
    if (!_isInitialized) return null;
    return _prefs.getString(_keyPlayerId);
  }

  /// Sauvegarde le thème (true = sombre)
  Future<void> saveTheme(bool isDark) async {
    _ensureInitialized();
    if (!_isInitialized) return;
    await _prefs.setBool(_keyTheme, isDark);
    notifyListeners();
  }

  /// Récupère le thème
  bool getTheme() {
    _ensureInitialized();
    if (!_isInitialized) return true; // Thème sombre par défaut
    return _prefs.getBool(_keyTheme) ?? true;
  }

  /// Sauvegarde le code admin
  Future<void> saveAdminCode(String code) async {
    _ensureInitialized();
    if (!_isInitialized) return;
    await _prefs.setString(_keyAdminCode, code);
    notifyListeners();
  }

  /// Récupère le code admin
  String? getAdminCode() {
    _ensureInitialized();
    if (!_isInitialized) return null;
    return _prefs.getString(_keyAdminCode);
  }

  /// Vérifie si le code admin est valide (strictement "ADMIN_2026")
  bool isAdmin() {
    final code = getAdminCode();
    return code == 'ADMIN_2026';
  }

  /// Vérifie si le code admin saisi est correct
  bool validateAdminCode(String code) {
    return code == 'ADMIN_2026';
  }

  /// Ajoute une partie à l'historique
  Future<void> addToHistory(GameHistoryEntry entry) async {
    _ensureInitialized();
    if (!_isInitialized) return;

    final history = getHistory();
    history.insert(0, entry);

    // Garde uniquement les 100 dernières parties
    if (history.length > 100) {
      history.removeRange(100, history.length);
    }

    await _prefs.setString(
      _keyHistory,
      jsonEncode(history.map((e) => e.toJson()).toList()),
    );
    notifyListeners();
  }

  /// Récupère l'historique des parties
  List<GameHistoryEntry> getHistory() {
    _ensureInitialized();
    if (!_isInitialized) return [];

    final historyJson = _prefs.getString(_keyHistory);
    if (historyJson == null) return [];

    try {
      final List<dynamic> decoded = jsonDecode(historyJson);
      return decoded
          .map((e) => GameHistoryEntry.fromJson(e as Map<String, dynamic>))
          .toList();
    } catch (e) {
      debugPrint('Erreur lecture historique: $e');
      return [];
    }
  }

  /// Efface l'historique
  Future<void> clearHistory() async {
    _ensureInitialized();
    if (!_isInitialized) return;
    await _prefs.remove(_keyHistory);
    notifyListeners();
  }

  /// Réinitialise toutes les données
  Future<void> resetAll() async {
    _ensureInitialized();
    if (!_isInitialized) return;
    await _prefs.clear();
    notifyListeners();
  }
}

/// Entrée d'historique de partie
class GameHistoryEntry {
  final String id;
  final String roomCode;
  final String mode;
  final int playerCount;
  final String result; // win, lose, cancelled
  final int ddkWon;
  final DateTime date;

  GameHistoryEntry({
    required this.id,
    required this.roomCode,
    required this.mode,
    required this.playerCount,
    required this.result,
    required this.ddkWon,
    required this.date,
  });

  Map<String, dynamic> toJson() => {
    'id': id,
    'roomCode': roomCode,
    'mode': mode,
    'playerCount': playerCount,
    'result': result,
    'ddkWon': ddkWon,
    'date': date.toIso8601String(),
  };

  factory GameHistoryEntry.fromJson(Map<String, dynamic> json) {
    return GameHistoryEntry(
      id: json['id'] as String,
      roomCode: json['roomCode'] as String,
      mode: json['mode'] as String,
      playerCount: json['playerCount'] as int,
      result: json['result'] as String,
      ddkWon: json['ddkWon'] as int,
      date: DateTime.parse(json['date'] as String),
    );
  }
}
