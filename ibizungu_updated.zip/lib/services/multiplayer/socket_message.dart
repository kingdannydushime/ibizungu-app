/// DTOs pour la communication socket multijoueur

import 'dart:convert';

/// Message socket de base
class SocketMessage {
  final String type;
  final String path;
  final Map<String, dynamic>? data;
  final String? messageId;

  SocketMessage({
    required this.type,
    required this.path,
    this.data,
    this.messageId,
  });

  Map<String, dynamic> toJson() => {
    'type': type,
    'path': path,
    'data': data,
    'messageId': messageId,
  };

  factory SocketMessage.fromJson(Map<String, dynamic> json) {
    return SocketMessage(
      type: json['type'] as String,
      path: json['path'] as String,
      data: json['data'] as Map<String, dynamic>?,
      messageId: json['messageId'] as String?,
    );
  }

  String encode() => jsonEncode(toJson());

  static SocketMessage? decode(String message) {
    try {
      final json = jsonDecode(message) as Map<String, dynamic>;
      return SocketMessage.fromJson(json);
    } catch (e) {
      return null;
    }
  }
}

/// Participant (joueur) dans une room
class GameParticipant {
  final String id;
  final String pseudo;
  final bool isHost;
  final bool isReady;
  final int ddkBalance;
  final String? teamId;

  GameParticipant({
    required this.id,
    required this.pseudo,
    this.isHost = false,
    this.isReady = false,
    this.ddkBalance = 1000,
    this.teamId,
  });

  Map<String, dynamic> toJson() => {
    'id': id,
    'pseudo': pseudo,
    'isHost': isHost,
    'isReady': isReady,
    'ddkBalance': ddkBalance,
    'teamId': teamId,
  };

  factory GameParticipant.fromJson(Map<String, dynamic> json) {
    return GameParticipant(
      id: json['id'] as String,
      pseudo: json['pseudo'] as String,
      isHost: json['isHost'] as bool? ?? false,
      isReady: json['isReady'] as bool? ?? false,
      ddkBalance: json['ddkBalance'] as int? ?? 1000,
      teamId: json['teamId'] as String?,
    );
  }
}

/// Message de connexion à une room
class JoinRoomMessage {
  final GameParticipant participant;
  final String roomCode;

  JoinRoomMessage({
    required this.participant,
    required this.roomCode,
  });

  Map<String, dynamic> toJson() => {
    'participant': participant.toJson(),
    'roomCode': roomCode,
  };

  factory JoinRoomMessage.fromJson(Map<String, dynamic> json) {
    return JoinRoomMessage(
      participant: GameParticipant.fromJson(json['participant'] as Map<String, dynamic>),
      roomCode: json['roomCode'] as String,
    );
  }
}

/// Message de déconnexion
class DisconnectMessage {
  final String participantId;
  final String roomCode;

  DisconnectMessage({
    required this.participantId,
    required this.roomCode,
  });

  Map<String, dynamic> toJson() => {
    'participantId': participantId,
    'roomCode': roomCode,
  };

  factory DisconnectMessage.fromJson(Map<String, dynamic> json) {
    return DisconnectMessage(
      participantId: json['participantId'] as String,
      roomCode: json['roomCode'] as String,
    );
  }
}

/// Message de liste des participants
class ParticipantsListMessage {
  final List<GameParticipant> participants;

  ParticipantsListMessage({required this.participants});

  Map<String, dynamic> toJson() => {
    'participants': participants.map((p) => p.toJson()).toList(),
  };

  factory ParticipantsListMessage.fromJson(Map<String, dynamic> json) {
    return ParticipantsListMessage(
      participants: (json['participants'] as List)
          .map((p) => GameParticipant.fromJson(p as Map<String, dynamic>))
          .toList(),
    );
  }
}

/// Message de mise à jour de l'état du jeu
class GameStateMessage {
  final Map<String, dynamic> gameState;

  GameStateMessage({required this.gameState});

  Map<String, dynamic> toJson() => {
    'gameState': gameState,
  };

  factory GameStateMessage.fromJson(Map<String, dynamic> json) {
    return GameStateMessage(
      gameState: json['gameState'] as Map<String, dynamic>,
    );
  }
}

/// Message de demande de mise à jour de l'état du jeu
class RequestStateMessage {
  final String participantId;

  RequestStateMessage({required this.participantId});

  Map<String, dynamic> toJson() => {
    'participantId': participantId,
  };

  factory RequestStateMessage.fromJson(Map<String, dynamic> json) {
    return RequestStateMessage(
      participantId: json['participantId'] as String,
    );
  }
}

/// Message d'action de jeu (jouer une carte)
class GameActionMessage {
  final String participantId;
  final String actionType;
  final Map<String, dynamic>? actionData;

  GameActionMessage({
    required this.participantId,
    required this.actionType,
    this.actionData,
  });

  Map<String, dynamic> toJson() => {
    'participantId': participantId,
    'actionType': actionType,
    'actionData': actionData,
  };

  factory GameActionMessage.fromJson(Map<String, dynamic> json) {
    return GameActionMessage(
      participantId: json['participantId'] as String,
      actionType: json['actionType'] as String,
      actionData: json['actionData'] as Map<String, dynamic>?,
    );
  }
}

/// Message de création de room
class CreateRoomMessage {
  final String roomCode;
  final GameParticipant host;
  final int gameMode; // 0 = individual, 1 = groups
  final int betAmount;
  final int playerCount;

  CreateRoomMessage({
    required this.roomCode,
    required this.host,
    this.gameMode = 0,
    this.betAmount = 50,
    this.playerCount = 4,
  });

  Map<String, dynamic> toJson() => {
    'roomCode': roomCode,
    'host': host.toJson(),
    'gameMode': gameMode,
    'betAmount': betAmount,
    'playerCount': playerCount,
  };

  factory CreateRoomMessage.fromJson(Map<String, dynamic> json) {
    return CreateRoomMessage(
      roomCode: json['roomCode'] as String,
      host: GameParticipant.fromJson(json['host'] as Map<String, dynamic>),
      gameMode: json['gameMode'] as int? ?? 0,
      betAmount: json['betAmount'] as int? ?? 50,
      playerCount: json['playerCount'] as int? ?? 4,
    );
  }
}

/// Message de room fermée
class RoomClosedMessage {
  final String roomCode;
  final String? reason;

  RoomClosedMessage({
    required this.roomCode,
    this.reason,
  });

  Map<String, dynamic> toJson() => {
    'roomCode': roomCode,
    'reason': reason,
  };

  factory RoomClosedMessage.fromJson(Map<String, dynamic> json) {
    return RoomClosedMessage(
      roomCode: json['roomCode'] as String,
      reason: json['reason'] as String?,
    );
  }
}

/// Message d'accusé de réception de connexion
class ConnectionAckMessage {
  final bool success;
  final String? error;
  final GameParticipant? participant;
  final List<GameParticipant>? existingParticipants;
  final String? roomCode;
  final Map<String, dynamic>? gameState; // État du jeu actuel

  ConnectionAckMessage({
    required this.success,
    this.error,
    this.participant,
    this.existingParticipants,
    this.roomCode,
    this.gameState,
  });

  Map<String, dynamic> toJson() => {
    'success': success,
    'error': error,
    'participant': participant?.toJson(),
    'existingParticipants': existingParticipants?.map((p) => p.toJson()).toList(),
    'roomCode': roomCode,
    'gameState': gameState,
  };

  factory ConnectionAckMessage.fromJson(Map<String, dynamic> json) {
    return ConnectionAckMessage(
      success: json['success'] as bool,
      error: json['error'] as String?,
      participant: json['participant'] != null
          ? GameParticipant.fromJson(json['participant'] as Map<String, dynamic>)
          : null,
      existingParticipants: json['existingParticipants'] != null
          ? (json['existingParticipants'] as List)
              .map((p) => GameParticipant.fromJson(p as Map<String, dynamic>))
              .toList()
          : null,
      roomCode: json['roomCode'] as String?,
      gameState: json['gameState'] as Map<String, dynamic>?,
    );
  }
}

/// Message de notification que la room est prête
class RoomReadyMessage {
  final String roomCode;
  final bool isReady;

  RoomReadyMessage({
    required this.roomCode,
    required this.isReady,
  });

  Map<String, dynamic> toJson() => {
    'roomCode': roomCode,
    'isReady': isReady,
  };

  factory RoomReadyMessage.fromJson(Map<String, dynamic> json) {
    return RoomReadyMessage(
      roomCode: json['roomCode'] as String,
      isReady: json['isReady'] as bool,
    );
  }
}

/// Message de démarrage du jeu
class GameStartMessage {
  final String roomCode;
  final Map<String, dynamic>? initialGameState;

  GameStartMessage({
    required this.roomCode,
    this.initialGameState,
  });

  Map<String, dynamic> toJson() => {
    'roomCode': roomCode,
    'initialGameState': initialGameState,
  };

  factory GameStartMessage.fromJson(Map<String, dynamic> json) {
    return GameStartMessage(
      roomCode: json['roomCode'] as String,
      initialGameState: json['initialGameState'] as Map<String, dynamic>?,
    );
  }
}

/// Message de fin de jeu
class GameOverMessage {
  final String roomCode;
  final String? winnerId;
  final String? message;
  final int potAmount;
  final Map<String, dynamic>? finalState;

  GameOverMessage({
    required this.roomCode,
    this.winnerId,
    this.message,
    this.potAmount = 0,
    this.finalState,
  });

  Map<String, dynamic> toJson() => {
    'roomCode': roomCode,
    'winnerId': winnerId,
    'message': message,
    'potAmount': potAmount,
    'finalState': finalState,
  };

  factory GameOverMessage.fromJson(Map<String, dynamic> json) {
    return GameOverMessage(
      roomCode: json['roomCode'] as String,
      winnerId: json['winnerId'] as String?,
      message: json['message'] as String?,
      potAmount: json['potAmount'] as int? ?? 0,
      finalState: json['finalState'] as Map<String, dynamic>?,
    );
  }
}
