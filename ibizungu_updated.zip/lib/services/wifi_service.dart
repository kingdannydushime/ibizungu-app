import 'dart:async';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:permission_handler/permission_handler.dart' as perm_handler;
import '../models/models.dart';
import 'multiplayer/multiplayer.dart';
import 'multiplayer/network_discovery_service.dart';

/// Service Wi-Fi pour le multijoueur local
/// Gère la communication entre joueurs sur le même réseau via sockets
class WiFiService extends ChangeNotifier {
  IbizunguSocketServer? _server;
  IbizunguSocketClient? _client;
  String? _roomCode;
  bool _isHost = false;
  Player? _currentPlayer;
  GameState? _remoteGameState;
  List<Player> _connectedPlayers = [];

  // ======= Network Scanning Properties =======
  NetworkDiscoveryService? _discoveryService;
  bool _isScanning = false;
  List<DiscoveredRoom> _discoveredRooms = [];
  Timer? _scanTimer;

  // Callback pour broadcaster l'état du jeu depuis le GameService
  Function(GameState)? _gameStateCallback;

  // Callback pour les actions de jeu (hôte uniquement)
  Function(String playerId, String actionType, Map<String, dynamic>? actionData)? _gameActionCallback;

  final List<Function(GameState)> _gameStateListeners = [];
  final List<Function(Player)> _playerJoinedListeners = [];
  final List<Function(String)> _playerLeftListeners = [];

  // Callback pour les salles découvertes
  final List<Function(List<DiscoveredRoom>)> _scanResultListeners = [];

  bool get isHost => _isHost;
  bool get isConnected => (_isHost && _server != null) || (_client?.isConnected ?? false);
  bool get isConnecting => _client?.isConnecting ?? false;
  String? get roomCode => _roomCode;
  List<Player> get connectedPlayers => _connectedPlayers;
  GameState? get remoteGameState => _remoteGameState;
  Player? get currentPlayer => _currentPlayer;

  // ======= Network Scanning Getters =======
  bool get isScanning => _isScanning;
  List<DiscoveredRoom> get discoveredRooms => List.unmodifiable(_discoveredRooms);

  // ======= Permission Status =======
  bool _hasLocationPermission = false;
  bool _hasNearbyWifiPermission = false;

  bool get hasLocationPermission => _hasLocationPermission;
  bool get hasNearbyWifiPermission => _hasNearbyWifiPermission;

  /// Vérifie et demande les permissions nécessaires pour le Wi-Fi
  /// Retourne true si toutes les permissions sont accordées
  Future<bool> checkAndRequestWifiPermissions() async {
    // Vérifie la version Android
    final androidInfo = await _getAndroidVersion();
    final isAndroid13Plus = androidInfo >= 33;

    // Sur Android 13+ (API 33+), on demande NEARBY_WIFI_DEVICES
    // Sur Android 10-12 (API 29-32), on demande ACCESS_FINE_LOCATION
    if (isAndroid13Plus) {
      // Android 13+ : demande Nearby WiFi Devices
      var nearbyStatus = await perm_handler.Permission.nearbyWifiDevices.status;
      if (nearbyStatus.isDenied) {
        nearbyStatus = await perm_handler.Permission.nearbyWifiDevices.request();
      }
      _hasNearbyWifiPermission = nearbyStatus.isGranted;

      // ACCESS_FINE_LOCATION reste nécessaire sur certains appareils
      var locationStatus = await perm_handler.Permission.locationWhenInUse.status;
      if (locationStatus.isDenied) {
        locationStatus = await perm_handler.Permission.locationWhenInUse.request();
      }
      _hasLocationPermission = locationStatus.isGranted;

      if (_hasNearbyWifiPermission && _hasLocationPermission) {
        debugPrint('Permissions WiFi accordées (Android 13+): NearbyWiFi + Location');
        return true;
      }
    } else {
      // Android 10-12 : demande ACCESS_FINE_LOCATION uniquement
      var locationStatus = await perm_handler.Permission.locationWhenInUse.status;
      if (locationStatus.isDenied) {
        locationStatus = await perm_handler.Permission.locationWhenInUse.request();
      }
      _hasLocationPermission = locationStatus.isGranted;

      if (_hasLocationPermission) {
        debugPrint('Permissions WiFi accordées (Android 10-12): Location');
        return true;
      }
    }

    debugPrint('Permissions WiFi refusées: Location=$_hasLocationPermission, NearbyWiFi=$_hasNearbyWifiPermission');
    return false;
  }

  /// Obtient la version Android (niveau API)
  /// Retourne le SDK level Android (ex: 33 pour Android 13)
  Future<int> _getAndroidVersion() async {
    try {
      // Essaye d'importer device_info_plus dynamiquement
      // En Flutter standard, on peut utiliser PlatformOperatingSystem
      // Cette implémentation utilise une méthode statique en attendant l'ajout du package

      // Solution: Utiliser la détection basée sur les features disponibles
      // Sur Android 13+ (API 33), nearbyWifiDevices permission existe
      // Sur Android 10-12 (API 29-32), on a locationWhenInUse

      // Vérifie d'abord les permissions réelles disponibles
      final nearbyStatus = await perm_handler.Permission.nearbyWifiDevices.status;
      if (nearbyStatus.isGranted) {
        // nearbyWifiDevices est disponible uniquement sur Android 13+
        return 33;
      }

      // Vérifie si location est disponible
      final locationStatus = await perm_handler.Permission.locationWhenInUse.status;
      if (locationStatus.isGranted) {
        // Location peut être sur Android 10-12 (API 29-32)
        // Retourne 30 comme approximation moyenne
        return 30;
      }

      // Par défaut, on assume Android 13+ pour les permissions WiFi
      // car le package nearbyWifiDevices est requis pour le scan WiFi
      return 33;
    } catch (e) {
      debugPrint('Erreur détection version Android: $e');
      // Retourne 33 par défaut (Android 13+) car c'est le minimum requis
      // pour le bon fonctionnement du scan WiFi moderne
      return 33;
    }
  }

  /// Vérifie si les permissions sont disponibles sans les demander
  Future<bool> hasWifiPermissions() async {
    final androidInfo = await _getAndroidVersion();
    final isAndroid13Plus = androidInfo >= 33;

    if (isAndroid13Plus) {
      final nearbyStatus = await perm_handler.Permission.nearbyWifiDevices.status;
      final locationStatus = await perm_handler.Permission.locationWhenInUse.status;
      _hasNearbyWifiPermission = nearbyStatus.isGranted;
      _hasLocationPermission = locationStatus.isGranted;
      return nearbyStatus.isGranted && locationStatus.isGranted;
    } else {
      final locationStatus = await perm_handler.Permission.locationWhenInUse.status;
      _hasLocationPermission = locationStatus.isGranted;
      return locationStatus.isGranted;
    }
  }

  /// Ouvre les paramètres de l'application pour l'utilisateur
  Future<void> openAppSettings() async {
    // Utilise la fonction correcte de permission_handler
    await perm_handler.openAppSettings();
  }

  /// Définit le callback pour broadcaster l'état du jeu
  void setBroadcastCallback(Function(GameState)? callback) {
    _gameStateCallback = callback;
  }

  /// Définit le callback pour les actions de jeu (hôte uniquement)
  void setGameActionCallback(Function(String playerId, String actionType, Map<String, dynamic>? actionData)? callback) {
    _gameActionCallback = callback;
  }

  /// Méthode interne pour broadcaster l'état (appelée par GameService)
  void _broadcastGameStateFromService(GameState state) {
    if (_gameStateCallback != null) {
      _gameStateCallback!(state);
    }
  }

  /// Initialise le service avec le joueur courant
  void init(Player player) {
    _currentPlayer = player;
    _connectedPlayers = [player];
  }

  /// Crée une salle en tant qu'hôte
  Future<bool> createRoom(String roomCode, Player host) async {
    try {
      _roomCode = roomCode;
      _isHost = true;
      _currentPlayer = host;
      _connectedPlayers = [host];

      // Crée et démarre le serveur
      _server = IbizunguSocketServer();

      // Configure les callbacks du serveur
      _setupServerCallbacks();

      // Démarre le serveur
      final success = await _server!.start();

      if (success) {
        // Configure la room avec l'hôte comme participant
        final hostParticipant = GameParticipant(
          id: host.id,
          pseudo: host.pseudo,
          isHost: true,
          isReady: true,
          ddkBalance: host.ddkBalance,
          teamId: host.teamId,
        );

        _server!.setRoom(roomCode, [hostParticipant]);
        _server!.setHostName(host.pseudo);
        notifyListeners();
        return true;
      }

      return false;
    } catch (e) {
      debugPrint('Erreur création salle: $e');
      return false;
    }
  }

  /// Configure les callbacks du serveur
  void _setupServerCallbacks() {
    _server?.onParticipantJoined = (participant) {
      debugPrint('Participant rejoint: ${(participant as GameParticipant).pseudo}');

      // Crée un Player à partir du GameParticipant
      final player = Player(
        id: participant.id,
        pseudo: participant.pseudo,
        ddkBalance: participant.ddkBalance,
        isHost: participant.isHost,
        teamId: participant.teamId,
        isReady: participant.isReady,
      );

      _notifyPlayerJoined(player);
    };

    _server?.onParticipantLeft = (participantId) {
      debugPrint('Participant parti: $participantId');
      final pid = participantId is String ? participantId : '';
      _notifyPlayerLeft(pid);
    };

    _server?.onParticipantsUpdated = (participants) {
      debugPrint('Participants mis à jour');
      // CORRIGÉ: Utiliser directement la liste reçue pour synchroniser
      final gps = participants as List<GameParticipant>;
      _connectedPlayers = gps.map((gp) => Player(
        id: gp.id,
        pseudo: gp.pseudo,
        ddkBalance: gp.ddkBalance,
        isHost: gp.isHost,
        teamId: gp.teamId,
        isReady: gp.isReady,
      )).toList();
      notifyListeners();
    };

    _server?.onGameAction = (data) {
      debugPrint('Action de jeu reçue: $data');
      // Transmet l'action au GameService via le callback
      if (data != null && _gameActionCallback != null) {
        final actionData = data as Map<String, dynamic>?;
        if (actionData != null) {
          final participantId = actionData['participantId'] as String? ?? '';
          final actionType = actionData['actionType'] as String? ?? '';
          final actionPayload = actionData['actionData'] as Map<String, dynamic>?;
          _gameActionCallback!(participantId, actionType, actionPayload);
        }
      }
    };

    // Callback pour demander l'état du jeu
    _server?.onGameStateRequested = (clientSocket) {
      debugPrint('État du jeu demandé par un client');
      // Récupère l'état actuel du GameService et l'envoie au client
      // Note: onGameStateCallback contient l'état à envoyer
      // Cette fonctionnalité sera utilisée quand le client joined
    };
  }

  /// Rejoint une salle en tant que client
  Future<bool> joinRoom(String hostAddress, int port, String roomCode, Player player) async {
    try {
      _roomCode = roomCode;
      _isHost = false;
      _currentPlayer = player;
      _connectedPlayers = [player];

      // Crée le client
      _client = IbizunguSocketClient();

      // Configure les callbacks du client
      _setupClientCallbacks();

      // Connecte au serveur
      final participant = GameParticipant(
        id: player.id,
        pseudo: player.pseudo,
        isHost: false,
        isReady: false,
        ddkBalance: player.ddkBalance,
        teamId: player.teamId,
      );

      final success = await _client!.connect(hostAddress, port, roomCode, participant);

      if (success) {
        notifyListeners();
        return true;
      }

      return false;
    } catch (e) {
      debugPrint('Erreur rejoindre salle: $e');
      return false;
    }
  }

  /// Configure les callbacks du client
  void _setupClientCallbacks() {
    _client?.onJoined = (participant) {
      debugPrint('Connecté à la room');
      _currentPlayer = Player(
        id: participant.id,
        pseudo: participant.pseudo,
        ddkBalance: participant.ddkBalance,
        isHost: participant.isHost,
        teamId: participant.teamId,
      );
      _connectedPlayers = [Player(
        id: participant.id,
        pseudo: participant.pseudo,
        ddkBalance: participant.ddkBalance,
        isHost: participant.isHost,
        teamId: participant.teamId,
      )];
      notifyListeners();
    };

    _client?.onParticipantsUpdated = (participants) {
      debugPrint('Participants mis à jour');
      // Met à jour la liste locale des joueurs
      _connectedPlayers = participants.map((gp) => Player(
        id: gp.id,
        pseudo: gp.pseudo,
        ddkBalance: gp.ddkBalance,
        isHost: gp.isHost,
        teamId: gp.teamId,
        isReady: gp.isReady,
      )).toList();
      notifyListeners();
    };

    _client?.onParticipantJoined = (participantId) {
      debugPrint('Nouveau participant: $participantId');
      // Le participant sera ajouté via onParticipantsUpdated
      notifyListeners();
    };

    _client?.onParticipantLeft = (participantId) {
      debugPrint('Participant parti: $participantId');
      _connectedPlayers.removeWhere((p) => p.id == participantId);
      _notifyPlayerLeft(participantId);
      notifyListeners();
    };

    _client?.onGameStateReceived = (gameState) {
      debugPrint('État du jeu reçu');
      _remoteGameState = GameState.fromJson(gameState);
      _notifyGameStateListeners();
      notifyListeners();
    };

    _client?.onGameStart = (initialState) {
      debugPrint('Jeu démarré');
      if (initialState.isNotEmpty) {
        _remoteGameState = GameState.fromJson(initialState);
        _notifyGameStateListeners();
      }
      notifyListeners();
    };

    _client?.onGameOver = (winnerId, message, potAmount, finalState) {
      debugPrint('Jeu terminé: $winnerId - $message');
      if (finalState != null) {
        _remoteGameState = GameState.fromJson(finalState);
        _notifyGameStateListeners();
      }
      notifyListeners();
    };

    _client?.onRoomClosed = () {
      debugPrint('Room fermée par l\'hôte');
      _notifyPlayerLeft('room_closed');
      notifyListeners();
    };

    _client?.onDisconnected = () {
      debugPrint('Déconnecté du serveur');
      notifyListeners();
    };

    _client?.onError = (error) {
      debugPrint('Erreur: $error');
      notifyListeners();
    };
  }

  /// Diffuse l'état du jeu à tous les clients (hôte uniquement)
  void broadcastGameState(GameState state) {
    if (_isHost && _server != null) {
      // Met à jour l'état du jeu sur le serveur pour les nouveaux clients
      _server!.setGameState(state.toJson());
      _server!.broadcastGameState(state.toJson());
    }
  }

  /// Diffuse le démarrage du jeu (hôte uniquement)
  void broadcastGameStart(GameState state) {
    if (_isHost && _server != null) {
      _server!.broadcastGameStart(state.toJson());
    }
  }

  /// Diffuse la fin du jeu (hôte uniquement)
  void broadcastGameOver(GameState state) {
    if (_isHost && _server != null) {
      _server!.broadcastGameOver(
        state.winnerId ?? '',
        state.message ?? 'Partie terminée',
        state.potAmount,
        state.toJson(),
      );
    }
  }

  /// Diffuse que la room est prête (hôte uniquement)
  void broadcastRoomReady(bool isReady) {
    if (_isHost && _server != null) {
      _server!.broadcastRoomReady(isReady);
    }
  }

  /// Demande l'état actuel du jeu (client uniquement)
  void requestGameState() {
    if (!_isHost && _client != null) {
      _client!.requestGameState();
    }
  }

  /// Envoie une action de jeu (client uniquement)
  void sendGameAction(String actionType, Map<String, dynamic>? actionData) {
    if (!_isHost && _client != null) {
      _client!.sendGameAction(actionType, actionData);
    }
  }

  /// Obtient l'adresse IP locale
  /// Obtient l'adresse IP locale de l'appareil
  Future<String?> getLocalIpAddress() async {
    try {
      // NOTE: On ne vérifie pas strictement hasWifiPermissions() ici car
      // NetworkInterface.list() peut fonctionner pour l'IP locale sans permissions de localisation
      // sur la plupart des versions d'Android.
      
      final interfaces = await NetworkInterface.list(
        type: InternetAddressType.IPv4,
        includeLinkLocal: false,
      );

      String? fallbackIp;

      for (var interface in interfaces) {
        for (var addr in interface.addresses) {
          if (!addr.isLoopback) {
            final ip = addr.address;
            // Priorise les plages privées standard (Wi-Fi, Hotspot, LAN)
            // 192.168.x.x, 10.x.x.x, et 172.16.x.x - 172.31.x.x
            if (ip.startsWith('192.168.') || 
                ip.startsWith('10.') || 
                ip.startsWith('172.')) {
              return ip;
            }
            fallbackIp = ip;
          }
        }
      }
      return fallbackIp;
    } catch (e) {
      debugPrint('Erreur getLocalIpAddress: $e');
      return null;
    }
  }

  /// Génère les données QR pour l'hôte
  Future<String> generateHostQrData() async {
    final localIp = await getLocalIpAddress() ?? '127.0.0.1';
    return 'IBZUNG:HOST:$localIp:8080:$_roomCode';
  }

  /// Génère les données QR pour le joueur
  Future<String> generatePlayerQrData() async {
    final localIp = await getLocalIpAddress() ?? '127.0.0.1';
    return 'IBZUNG:PLAYER:$localIp:8080:$_roomCode';
  }

  /// Parse les données QR pour rejoindre une partie
  static Map<String, dynamic>? parseQrData(String data) {
    try {
      final parts = data.split(':');
      if (parts.length < 5) return null;

      final prefix = parts[0];
      final type = parts[1];
      final ip = parts[2];
      final port = parts[3];
      final roomCode = parts[4];

      if (prefix != 'IBZUNG') return null;
      if (type != 'HOST' && type != 'PLAYER') return null;

      final ipRegex = RegExp(r'^(\d{1,3}\.){3}\d{1,3}$');
      if (!ipRegex.hasMatch(ip)) return null;

      final portNum = int.tryParse(port);
      if (portNum == null || portNum < 1 || portNum > 65535) return null;

      final roomCodeRegex = RegExp(r'^\d{6}$');
      if (!roomCodeRegex.hasMatch(roomCode)) return null;

      return {
        'hostIp': ip,
        'port': portNum,
        'roomCode': roomCode,
        'type': type,
      };
    } catch (e) {
      debugPrint('Erreur parsing QR: $e');
      return null;
    }
  }

  /// Valide les données de connexion
  static bool validateConnectionData(String? ip, String? port, String? roomCode) {
    if (ip == null || ip.isEmpty) return false;
    if (port == null || port.isEmpty) return false;
    if (roomCode == null || roomCode.isEmpty) return false;

    final ipRegex = RegExp(r'^(\d{1,3}\.){3}\d{1,3}$');
    if (!ipRegex.hasMatch(ip)) return false;

    final portNum = int.tryParse(port);
    if (portNum == null || portNum < 1 || portNum > 65535) return false;

    final roomCodeRegex = RegExp(r'^\d{6}$');
    if (!roomCodeRegex.hasMatch(roomCode)) return false;

    return true;
  }

  /// Génère un code de salle
  static String generateRoomCode() {
    final random = DateTime.now().millisecondsSinceEpoch % 900000;
    return (random + 100000).toString();
  }

  // ============ Network Scanning Methods ============

  /// Ajoute un listener pour les résultats du scan
  void addScanResultListener(Function(List<DiscoveredRoom>) listener) {
    _scanResultListeners.add(listener);
  }

  void removeScanResultListener(Function(List<DiscoveredRoom>) listener) {
    _scanResultListeners.remove(listener);
  }

  /// Démarre le scan du réseau pour trouver des salles
  Future<void> startNetworkScan() async {
    // BUG FIX #8: Vérifie et demande les permissions Wi-Fi avant le scan
    final hasPermissions = await checkAndRequestWifiPermissions();
    if (!hasPermissions) {
      debugPrint('Permissions WiFi refusées - Scan annulé');
      notifyListeners();
      return;
    }

    // CORRIGÉ: Annuler le timer précédent s'il existe
    _scanTimer?.cancel();
    _scanTimer = null;

    if (_isScanning) return;

    _isScanning = true;
    _discoveredRooms.clear();
    notifyListeners();

    _discoveryService = NetworkDiscoveryService();

    _discoveryService!.onRoomDiscovered = (room) {
      if (!_discoveredRooms.any((r) => r.ipAddress == room.ipAddress && r.port == room.port)) {
        _discoveredRooms.add(room);
        debugPrint('Salle découverte: ${room.ipAddress}');
        notifyListeners();
      }
    };

    _discoveryService!.onRoomRemoved = (ipAddress) {
      // Compter avant de supprimer car removeWhere retourne void
      final count = _discoveredRooms.where((r) => r.ipAddress == ipAddress).length;
      _discoveredRooms.removeWhere((r) => r.ipAddress == ipAddress);
      if (count > 0) {
        notifyListeners();
      }
    };

    await _discoveryService!.startScan();

    // Continue le scan pendant 5 secondes
    _scanTimer = Timer(const Duration(seconds: 5), () {
      stopNetworkScan();
    });
  }

  /// Arrête le scan réseau
  void stopNetworkScan() {
    _scanTimer?.cancel();
    _scanTimer = null;
    _isScanning = false;
    _discoveryService?.dispose();
    _discoveryService = null;

    // Notifie les listeners avec les résultats finaux
    for (var listener in _scanResultListeners) {
      listener(_discoveredRooms);
    }
    notifyListeners();
  }

  /// Obtient les informations réseau locales
  /// BUG FIX #8: Vérifie les permissions avant d'accéder au réseau
  Future<Map<String, String>?> getNetworkInfo() async {
    try {
      // Vérifie les permissions avant d'accéder au réseau
      final hasPermissions = await hasWifiPermissions();
      if (!hasPermissions) {
        debugPrint('Permissions WiFi non accordées - getNetworkInfo() annulé');
        return null;
      }

      final interfaces = await NetworkInterface.list(
        type: InternetAddressType.IPv4,
        includeLinkLocal: false,
      );

      for (var interface in interfaces) {
        for (var addr in interface.addresses) {
          if (!addr.isLoopback && !addr.isLinkLocal) {
            // Calcule l'adresse de broadcast
            final parts = addr.address.split('.');
            final broadcastAddr = '${parts[0]}.${parts[1]}.${parts[2]}.255';

            return {
              'ip': addr.address,
              'broadcast': broadcastAddr,
              'subnet': '${parts[0]}.${parts[1]}.${parts[2]}',
            };
          }
        }
      }
      return null;
    } catch (e) {
      debugPrint('Erreur obtention info réseau: $e');
      return null;
    }
  }

  /// Méthode pour TCP scan d'une IP spécifique
  /// Teste si un serveur Ibizungu est en cours d'exécution sur le port 8080
  /// CORRIGÉ: Gestion propre des sockets et timeout pour éviter les race conditions
  /// BUG FIX #8: Vérifie les permissions avant le scan
  Future<DiscoveredRoom?> probeHost(String ip, {int port = 8080}) async {
    Socket? socket;
    try {
      // Vérifie les permissions avant d'effectuer le scan
      final hasPermissions = await hasWifiPermissions();
      if (!hasPermissions) {
        return null;
      }

      socket = await Socket.connect(
        ip,
        port,
        timeout: const Duration(milliseconds: 500),
      );

      // Envoie une requête ping pour vérifier si c'est un serveur Ibizungu
      socket.write('{"type":"ping","path":"/ping"}\n');
      
      // Écoute la réponse avec un timeout propre
      final completer = Completer<DiscoveredRoom?>();
      
      // Timeout pour fermer le socket et compléter
      Timer? timer = Timer(const Duration(seconds: 2), () {
        if (!completer.isCompleted) {
          completer.complete(null);
          socket?.close();
        }
      });

      socket.listen(
        (data) {
          timer?.cancel();
          try {
            final response = utf8.decode(data);
            // Accepte tout message non vide comme réponse valide du serveur
            if (response.isNotEmpty && !completer.isCompleted) {
              completer.complete(DiscoveredRoom(
                ipAddress: ip,
                port: port,
                hostName: 'Serveur Ibizungu',
              ));
            } else if (!completer.isCompleted) {
              completer.complete(null);
            }
          } catch (e) {
            if (!completer.isCompleted) {
              completer.complete(null);
            }
          }
          socket?.close();
        }, 
        onError: (e) {
          timer?.cancel();
          if (!completer.isCompleted) {
            completer.complete(null);
          }
          socket?.close();
        }, 
        onDone: () {
          timer?.cancel();
          if (!completer.isCompleted) {
            completer.complete(null);
          }
        },
      );

      return completer.future;
    } catch (e) {
      debugPrint('Probe $ip:$port échoué: $e');
      socket?.close();
      return null;
    }
  }

  /// Scan TCP du réseau local pour trouver les serveurs
  /// BUG FIX #8: Vérifie les permissions avant le scan
  Future<List<DiscoveredRoom>> scanNetworkRange(String subnet, {int start = 1, int end = 254}) async {
    // Vérifie les permissions avant d'effectuer le scan
    final hasPermissions = await hasWifiPermissions();
    if (!hasPermissions) {
      debugPrint('Permissions WiFi refusées - scanNetworkRange() annulé');
      return [];
    }

    final List<DiscoveredRoom> foundRooms = [];

    // Scan parallèle des addresses
    final futures = <Future<DiscoveredRoom?>>[];
    for (int i = start; i <= end; i++) {
      final ip = '$subnet.$i';
      futures.add(probeHost(ip));
    }

    final results = await Future.wait(futures);
    for (var room in results) {
      if (room != null) {
        foundRooms.add(room);
      }
    }

    return foundRooms;
  }

  // ============ Listeners ============

  /// Ajoute un listener pour l'état du jeu
  void addGameStateListener(Function(GameState) listener) {
    _gameStateListeners.add(listener);
  }

  void removeGameStateListener(Function(GameState) listener) {
    _gameStateListeners.remove(listener);
  }

  void _notifyGameStateListeners() {
    if (_remoteGameState != null) {
      for (var listener in _gameStateListeners) {
        listener(_remoteGameState!);
      }
      notifyListeners();
    }
  }

  /// Ajoute un listener pour les connexions
  void addPlayerJoinedListener(Function(Player) listener) {
    _playerJoinedListeners.add(listener);
  }

  void removePlayerJoinedListener(Function(Player) listener) {
    _playerJoinedListeners.remove(listener);
  }

  void _notifyPlayerJoined(Player player) {
    if (!_connectedPlayers.any((p) => p.id == player.id)) {
      _connectedPlayers.add(player);
    }
    for (var listener in _playerJoinedListeners) {
      listener(player);
    }
    notifyListeners();
  }

  /// Ajoute un listener pour les déconnections
  void addPlayerLeftListener(Function(String) listener) {
    _playerLeftListeners.add(listener);
  }

  void removePlayerLeftListener(Function(String) listener) {
    _playerLeftListeners.remove(listener);
  }

  void _notifyPlayerLeft(String playerId) {
    _connectedPlayers.removeWhere((p) => p.id == playerId);
    for (var listener in _playerLeftListeners) {
      listener(playerId);
    }
    notifyListeners();
  }

  /// Quitte la salle
  Future<void> leaveRoom() async {
    if (_isHost) {
      // Hôte: ferme le serveur
      if (_server != null) {
        _server!.closeRoom('L\'hôte a quitté');
        await _server!.dispose();
        _server = null;
      }
    } else {
      // Client: se déconnecte
      if (_client != null) {
        await _client!.dispose();
        _client = null;
      }
    }

    _roomCode = null;
    _isHost = false;
    _currentPlayer = null;
    _remoteGameState = null;
    _connectedPlayers.clear();

    notifyListeners();
  }

  @override
  void dispose() {
    leaveRoom();
    super.dispose();
  }
}
