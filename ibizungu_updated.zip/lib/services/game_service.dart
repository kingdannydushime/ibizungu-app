import 'dart:math';
import 'package:flutter/foundation.dart';
import '../models/models.dart';

/// Service de gestion du jeu Ibizungu
/// Gère la logique du jeu, les cartes, les plis et le scoring
class GameService extends ChangeNotifier {
  GameState? _gameState;
  final List<Function(GameState)> _stateListeners = [];
  List<PlayingCard>? _currentTrickCards; // Cartes jouées dans le pli actuel
  List<String>? _currentTrickPlayerIds; // IDs des joueurs ayant joué dans le pli actuel

  /// Callback pour broadcaster l'état du jeu aux autres joueurs via WiFi
  Function(GameState)? onGameStateChanged;

  GameState? get gameState => _gameState;

  /// Définit le callback pour broadcaster l'état
  void setBroadcastCallback(Function(GameState)? callback) {
    onGameStateChanged = callback;
  }

  /// Met à jour l'état du jeu depuis une source distante
  /// Appelée quand on reçoit l'état du jeu d'un autre joueur
  void updateFromRemote(GameState remoteState) {
    _gameState = remoteState;
    _notifyListeners();
    notifyListeners(); // Garantir la notification pour context.watch
  }

  /// Broadcast l'état actuel aux autres joueurs
  void _broadcastState() {
    if (_gameState != null && onGameStateChanged != null) {
      onGameStateChanged!(_gameState!);
    }
  }

  /// Ajoute un listener pour les changements d'état
  void addStateListener(Function(GameState) listener) {
    _stateListeners.add(listener);
  }

  void removeStateListener(Function(GameState) listener) {
    _stateListeners.remove(listener);
  }

  void _notifyListeners() {
    if (_gameState != null) {
      for (var listener in _stateListeners) {
        listener(_gameState!);
      }
      notifyListeners();
    }
  }

  /// Crée une nouvelle partie
  void createGame({
    required String roomCode,
    required Player host,
    required GameMode mode,
    int initialBet = 50,
  }) {
    _gameState = GameState(
      roomCode: roomCode,
      mode: mode,
      status: GameStatus.waiting,
      players: [host.copyWith(isHost: true)],
      deck: _createDeck(),
      createdAt: DateTime.now(),
      currentBet: initialBet,
    );
    _notifyListeners();
    _broadcastState();
  }

  /// Crée le paquet de 24 cartes
  List<PlayingCard> _createDeck() {
    final deck = <PlayingCard>[];
    int idCounter = 0;

    for (var suit in CardSuit.values) {
      for (var rank in CardRank.values) {
        deck.add(PlayingCard(
          suit: suit,
          rank: rank,
          id: 'card_${idCounter++}',
        ));
      }
    }

    return deck;
  }

  /// Mélange le paquet
  List<PlayingCard> _shuffleDeck(List<PlayingCard> deck) {
    final shuffled = List<PlayingCard>.from(deck);
    shuffled.shuffle(Random());
    return shuffled;
  }

  /// Ajoute un joueur à la partie
  void addPlayer(Player player) {
    if (_gameState == null) return;

    // Vérifie si le joueur n'est pas déjà présent
    if (_gameState!.players.any((p) => p.id == player.id)) return;

    final currentCount = _gameState!.players.length;

    // Vérifie le nombre max de joueurs (max 6)
    if (currentCount >= 6) return;

    final updatedPlayers = List<Player>.from(_gameState!.players)..add(player);

    _gameState = _gameState!.copyWith(players: updatedPlayers);
    _notifyListeners();
    _broadcastState();
  }

  /// Retire un joueur de la partie
  void removePlayer(String playerId) {
    if (_gameState == null) return;

    final updatedPlayers = _gameState!.players
        .where((p) => p.id != playerId)
        .toList();

    _gameState = _gameState!.copyWith(players: updatedPlayers);

    if (updatedPlayers.isEmpty) {
      _gameState = _gameState!.copyWith(status: GameStatus.cancelled);
    }

    _notifyListeners();
  }

  /// Démarre la phase de mise
  void startBetPhase() {
    if (_gameState == null) return;

    _gameState = _gameState!.copyWith(status: GameStatus.bet);
    _notifyListeners();
    _broadcastState();
  }

  /// Place une mise
  void placeBet(int amount) {
    if (_gameState == null) return;

    // Vérifie que tous les joueurs ont assez de DDK
    final playersWithBet = _gameState!.players.map((p) {
      return p.copyWith(ddkBalance: p.ddkBalance - amount);
    }).toList();

    final potAmount = amount * _gameState!.players.length;

    _gameState = _gameState!.copyWith(
      players: playersWithBet,
      potAmount: potAmount,
      currentBet: amount,
    );
    _notifyListeners();
    _broadcastState();
  }

  /// Distribue les cartes et détermine la couleur forte
  /// ncartes = 24 / nombre de joueurs
  /// Le premier joueur reçoit n cartes, sa dernière carte est mise sur la table (iyatotse)
  void dealCards() {
    if (_gameState == null) return;

    // CORRIGÉ: Mélanger d'abord, puis distribuer dans l'ordre du paquet mélangé
    final shuffledDeck = _shuffleDeck(_gameState!.deck);
    final playerCards = <String, List<PlayingCard>>{};
    final playerCount = _gameState!.players.length;
    final cardsPerPlayer = 24 ~/ playerCount;  // 24/3=8, 24/4=6, 24/6=4

    // Convertir le deck mélangé en liste pour un accès séquentiel
    final deckList = shuffledDeck.toList();
    int cardIndex = 0;

    // Distribue les cartes à chaque joueur dans l'ordre du paquet mélangé
    for (int i = 0; i < playerCount; i++) {
      final player = _gameState!.players[i];
      // Prend les prochaines cartes du paquet mélangé
      final cards = deckList.sublist(cardIndex, cardIndex + cardsPerPlayer);
      cardIndex += cardsPerPlayer;

      if (i == 0) {
        // Premier joueur: prend n cartes, retire 1 pour iyatotse (la dernière)
        final iyatotseCard = cards.last;

        // Met la carte iyatotse sur la table (pas dans playerCards)
        playerCards[player.id] = cards.sublist(0, cards.length - 1);

        _gameState = _gameState!.copyWith(
          status: GameStatus.playing,
          deck: shuffledDeck,  // Met à jour avec le deck mélangé
          playerCards: playerCards,
          strongSuit: iyatotseCard.suit,
          tableCards: [iyatotseCard],  // La carte iyatotse est sur la table
          currentPlayerIndex: 0,
          trickNumber: 1,
          message: 'Couleur forte (iyatotse): ${iyatotseCard.suitSymbol}',
        );

        // CORRIGÉ: Vérifie VETO immédiatement après la distribution
        final vetoWinner = _checkVetoAtDistribution(null);
        if (vetoWinner != null) {
          _gameState = _gameState!.copyWith(
            status: GameStatus.finished,
            tableCards: [],
            winnerId: vetoWinner,
            message: 'VETO! ${_getWinnerName(vetoWinner)} gagne!',
          );
          _notifyListeners();
          _broadcastState();
          return;
        }
      } else {
        playerCards[player.id] = cards;
      }
    }

    // Initialise le suivi du premier pli pour kurongora
    _currentTrickCards = [];
    _currentTrickPlayerIds = [];

    _notifyListeners();
    _broadcastState();
  }

  /// Helper pour obtenir le nom du gagnant
  String _getWinnerName(String winnerId) {
    if (_gameState == null) return 'Inconnu';

    // Vérifie si c'est une équipe
    final teamPlayers = _gameState!.players.where((p) => p.teamId == winnerId);
    if (teamPlayers.isNotEmpty) {
      return 'Équipe ${winnerId}';
    }

    // Sinon c'est un joueur
    final player = _gameState!.players.where((p) => p.id == winnerId).firstOrNull;
    return player?.pseudo ?? 'Inconnu';
  }

  /// Joue une carte (depuis l'interface locale)
  void playCard(String playerId, PlayingCard card) {
    _playCardInternal(playerId, card, fromNetwork: false);
  }

  /// Joue une carte depuis le réseau (sans re-broadcast pour éviter les boucles)
  void playCardFromNetwork(String playerId, PlayingCard card) {
    _playCardInternal(playerId, card, fromNetwork: true);
  }

  /// Méthode interne pour jouer une carte
  void _playCardInternal(String playerId, PlayingCard card, {required bool fromNetwork}) {
    if (_gameState == null) return;
    if (_gameState!.status != GameStatus.playing) return;

    final currentPlayer = _gameState!.currentPlayer;
    if (currentPlayer?.id != playerId) return;

    // CORRIGÉ: Validation de la carte jouée selon les règles du jeu
    final validationError = _validateCardPlay(playerId, card);
    if (validationError != null) {
      debugPrint('Carte invalide: $validationError');
      return;  // Refuse la carte si elle n'est pas valide
    }

    // Retire la carte de la main du joueur
    final playerHand = List<PlayingCard>.from(
      _gameState!.playerCards[playerId] ?? [],
    );
    playerHand.remove(card);

    final updatedPlayerCards = Map<String, List<PlayingCard>>.from(
      _gameState!.playerCards,
    );
    updatedPlayerCards[playerId] = playerHand;

    // Ajoute la carte sur la table
    final tableCards = List<PlayingCard>.from(_gameState!.tableCards)..add(card);

    // Ajoute aux cartes du pli actuel
    _currentTrickCards!.add(card);
    _currentTrickPlayerIds!.add(playerId);

    // Passe au joueur suivant
    final nextPlayerIndex = (_gameState!.currentPlayerIndex + 1) %
        _gameState!.players.length;

    // Vérifie si le pli est terminé (tous les joueurs ont joué)
    if (tableCards.length == _gameState!.players.length) {
      _resolveTrick(tableCards);
    } else {
      _gameState = _gameState!.copyWith(
        playerCards: updatedPlayerCards,
        tableCards: tableCards,
        currentPlayerIndex: nextPlayerIndex,
      );
      _notifyListeners();
      _broadcastState();
    }
  }

  /// Valide si un joueur peut jouer une carte
  /// Retourne null si valide, sinon un message d'erreur
  String? _validateCardPlay(String playerId, PlayingCard card) {
    if (_gameState == null) return 'Partie non initialisée';
    
    // Vérifie si c'est au tour du joueur
    final currentPlayer = _gameState!.currentPlayer;
    if (currentPlayer?.id != playerId) {
      return 'Ce n\'est pas votre tour';
    }
    
    // Vérifie si le joueur a la carte en main
    final playerHand = _gameState!.playerCards[playerId] ?? [];
    if (!playerHand.any((c) => c.id == card.id)) {
      return 'Vous n\'avez pas cette carte en main';
    }
    
    return null;
  }

  /// Retourne le nom d'une couleur
  String _getSuitName(CardSuit suit) {
    switch (suit) {
      case CardSuit.hearts:
        return 'Cœurs (♥)';
      case CardSuit.diamonds:
        return 'Carreaux (♦)';
      case CardSuit.clubs:
        return 'Trèfles (♣)';
      case CardSuit.spades:
        return 'Piques (♠)';
    }
  }

  /// Résout un pli
  void _resolveTrick(List<PlayingCard> tableCards) {
    if (_gameState == null) return;

    // Vérifie le kurongora AVANT de résoudre le pli
    // Si deux joueurs de même équipe jouent As et 7 de la couleur forte dans le même pli
    if (_gameState!.mode == GameMode.groups) {
      final kurongoraResult = _checkKurongoraInTrick();
      if (kurongoraResult != null) {
        _gameState = _gameState!.copyWith(
          status: GameStatus.finished,
          tableCards: [],
          winnerId: kurongoraResult,
          message: 'KURONGORA! L\'équipe perd!',
        );
        _notifyListeners();
        _broadcastState();
        return;
      }
    }

    // Détermine le gagnant du pli
    final winner = _determineTrickWinner(tableCards);
    final winnerPlayer = _gameState!.players.firstWhere((p) => p.id == winner);

    // Passe au joueur suivant qui a gagné le pli
    final winnerIndex = _gameState!.players.indexOf(winnerPlayer);

    // Vérifie si la partie est terminée
    bool isGameOver = false;
    String? winnerId;
    String? message;

    // Vérifie les victoires automatiques

    // Vérifie veto SEULEMENT lors de la première distribution
    // (quand trickNumber == 1 et c'est le premier pli)
    if (_gameState!.trickNumber == 1 && tableCards.length == _gameState!.players.length) {
      final vetoResult = _checkVetoAtDistribution(winner);
      if (vetoResult != null) {
        isGameOver = true;
        winnerId = vetoResult;
        message = 'VETO! ${_gameState!.players.firstWhere((p) => p.id == vetoResult).pseudo} gagne!';
      }
    }

    // Vérifie si tous les joueurs n'ont plus de cartes (fin de partie)
    if (!isGameOver && _checkAllCardsPlayed()) {
      isGameOver = true;

      // Vérifie kappa à la fin de la partie
      final kappaResult = _checkKappaAtEnd();
      if (kappaResult != null) {
        winnerId = kappaResult;
        message = 'KAPPA! ${_gameState!.players.firstWhere((p) => p.id == kappaResult).pseudo} gagne!';
      } else {
        // Détermine le gagnant selon les ibimari ou les points
        final finalWinner = _determineFinalWinner();

        // Vérifie si c'est une égalité (personne ne gagne)
        if (finalWinner.isEmpty) {
          winnerId = null;
          message = 'ÉGALITÉ! Personne ne gagne. Les DDK ne sont pas redistribués.';
        } else {
          winnerId = finalWinner;
          final winnerName = _gameState!.players.firstWhere((p) => p.id == finalWinner).pseudo;

          // Compte les ibimari pour le message
          final myIbimari = _countIbimari(_gameState!.playerCards[finalWinner] ?? []);

          if (_gameState!.mode == GameMode.groups) {
            message = 'Partie terminée! Équipe de $winnerName gagne avec $myIbimari ibimari!';
          } else {
            message = 'Partie terminée! $winnerName gagne avec $myIbimari ibimari!';
          }
        }
      }
    }

    if (isGameOver) {
      _gameState = _gameState!.copyWith(
        status: GameStatus.finished,
        tableCards: [],
        clearWinnerId: winnerId == null,
        winnerId: winnerId,
        message: message,
      );

      // Redistribue les DDK au gagnant SEULEMENT si quelqu'un a gagné
      if (winnerId != null && winnerId.isNotEmpty) {
        _distributePotToWinner(winnerId);
      }
      // Sinon: personne ne gagne, les DDK restent dans le pot (non redistribués)
    } else {
      _gameState = _gameState!.copyWith(
        tableCards: [],
        currentPlayerIndex: winnerIndex,
        trickNumber: _gameState!.trickNumber + 1,
        message: '${winnerPlayer.pseudo} gagne le pli!',
      );

      // Réinitialise le suivi du pli pour kurongora
      _currentTrickCards = [];
      _currentTrickPlayerIds = [];
    }

    _notifyListeners();
    _broadcastState();
  }
  
  /// Redistribue le pot au gagnant
  void _distributePotToWinner(String winnerId) {
    if (_gameState == null) return;
    
    final updatedPlayers = _gameState!.players.map((p) {
      if (p.id == winnerId) {
        return p.copyWith(ddkBalance: p.ddkBalance + _gameState!.potAmount);
      }
      return p;
    }).toList();
    
    _gameState = _gameState!.copyWith(players: updatedPlayers);
  }

  /// Détermine le gagnant d'un pli
  String _determineTrickWinner(List<PlayingCard> tableCards) {
    if (_gameState == null || tableCards.isEmpty) return '';

    final strongSuit = _gameState!.strongSuit;
    PlayingCard winningCard = tableCards.first;
    String winnerId = _gameState!.players[0].id;

    // La première carte sur le tapis détermine la couleur jouée
    final leadSuit = tableCards.first.suit;

    for (int i = 1; i < tableCards.length; i++) {
      final card = tableCards[i];

      // Si la carte est de la couleur forte et pas la carte actuelle
      if (card.suit == strongSuit && winningCard.suit != strongSuit) {
        winningCard = card;
        winnerId = _gameState!.players[i].id;
      }
      // Si les deux sont de la couleur forte
      else if (card.suit == strongSuit && winningCard.suit == strongSuit) {
        if (card.hierarchy > winningCard.hierarchy) {
          winningCard = card;
          winnerId = _gameState!.players[i].id;
        }
      }
      // Si la carte est de la couleur demandée et pas la carte actuelle
      else if (card.suit == leadSuit && winningCard.suit == leadSuit) {
        if (card.hierarchy > winningCard.hierarchy) {
          winningCard = card;
          winnerId = _gameState!.players[i].id;
        }
      }
      // Si la carte est de la couleur demandée mais pas la carte actuelle
      else if (card.suit == leadSuit && winningCard.suit != leadSuit) {
        winningCard = card;
        winnerId = _gameState!.players[i].id;
      }
    }

    return winnerId;
  }

  /// Vérifie kurongora : deux joueurs de même équipe jouent As et 7 de la couleur forte dans le même pli
  /// RETOURNE: l'ID de l'équipe perdante ou null si pas de kurongora
  String? _checkKurongoraInTrick() {
    if (_gameState == null || _currentTrickCards == null || _currentTrickPlayerIds == null) return null;
    if (_currentTrickCards!.length < 2) return null;
    
    final strongSuit = _gameState!.strongSuit;
    
    // Trouve les joueurs qui ont joué As et 7 de la couleur forte
    final playersWithStrongAce = <String>[];
    final playersWithStrongSeven = <String>[];
    
    for (int i = 0; i < _currentTrickCards!.length; i++) {
      final card = _currentTrickCards![i];
      final playerId = _currentTrickPlayerIds![i];
      
      if (card.suit == strongSuit && card.rank == CardRank.ace) {
        playersWithStrongAce.add(playerId);
      } else if (card.suit == strongSuit && card.rank == CardRank.seven) {
        playersWithStrongSeven.add(playerId);
      }
    }
    
    // Si un joueur a As et un autre a 7 (même équipe)
    if (playersWithStrongAce.isNotEmpty && playersWithStrongSeven.isNotEmpty) {
      final playerWithAce = _gameState!.players.firstWhere((p) => p.id == playersWithStrongAce.first);
      final playerWithSeven = _gameState!.players.firstWhere((p) => p.id == playersWithStrongSeven.first);
      
      // Vérifie si même équipe
      if (playerWithAce.teamId != null && playerWithAce.teamId == playerWithSeven.teamId) {
        // Même équipe - ils PERDENT
        return playerWithAce.teamId;
      }
    }
    
    return null;
  }

  /// Vérifie veto : joueur possède toutes les cartes d'une même couleur à la distribution
  /// Le joueur doit avoir n cartes d'une couleur (n = nombre de joueurs)
  /// Ex: 4 joueurs → 6 cartes d'une couleur pour veto
  /// RETOURNE: l'ID du joueur/équipe gagnante ou null
  String? _checkVetoAtDistribution(String? trickWinnerId) {
    if (_gameState == null) return null;

    final cardsPerPlayer = 24 ~/ _gameState!.players.length;

    for (var player in _gameState!.players) {
      final hand = _gameState!.playerCards[player.id] ?? [];

      for (var suit in CardSuit.values) {
        final suitCards = hand.where((c) => c.suit == suit).toList();
        // Vérifie si le joueur a n cartes d'une couleur (n = nombre de joueurs)
        if (suitCards.length == cardsPerPlayer) {
          // En mode groupes, retourne l'ID de l'équipe
          if (_gameState!.mode == GameMode.groups && player.teamId != null) {
            return player.teamId;
          }
          // En mode individuel, retourne l'ID du joueur
          return player.id;
        }
      }
    }

    return null;
  }

  /// Vérifie kappa à la fin de la partie : 5 ibimari et plus de 10 points
  /// RETOURNE: l'ID du joueur/équipe gagnante ou null
  String? _checkKappaAtEnd() {
    if (_gameState == null) return null;

    // En mode Individuel
    if (_gameState!.mode == GameMode.individual) {
      for (var player in _gameState!.players) {
        final hand = _gameState!.playerCards[player.id] ?? [];
        final ibimariCount = _countIbimari(hand);
        final pointsCount = _calculatePoints(hand);

        // Kappa : 5 ibimari ET plus de 10 points
        if (ibimariCount >= 5 && pointsCount > 10) {
          return player.id;
        }
      }
    }
    // En mode Groupes
    else {
      final teamCards = <String, List<PlayingCard>>{};
      for (var player in _gameState!.players) {
        if (player.teamId != null) {
          final hand = _gameState!.playerCards[player.id] ?? [];
          teamCards.putIfAbsent(player.teamId!, () => []);
          teamCards[player.teamId!]!.addAll(hand);
        }
      }

      for (var entry in teamCards.entries) {
        final teamIbimari = entry.value.where((c) => c.isIbimari).toList();
        final teamPointsVal = entry.value.fold<int>(0, (sum, card) => sum + card.points);

        if (teamIbimari.length >= 5 && teamPointsVal > 10) {
          return entry.key;
        }
      }
    }

    return null;
  }

  /// Retourne tous les ibimari (As et 7) du jeu
  List<PlayingCard> _getAllIbimari() {
    return _gameState!.deck.where((c) => c.isIbimari).toList();
  }
  
  /// Compte les ibimari dans une main
  int _countIbimari(List<PlayingCard> hand) {
    return hand.where((c) => c.isIbimari).length;
  }

  /// Vérifie si tous les joueurs ont joué toutes leurs cartes
  bool _checkAllCardsPlayed() {
    if (_gameState == null) return false;

    for (var player in _gameState!.players) {
      final hand = _gameState!.playerCards[player.id] ?? [];
      if (hand.isNotEmpty) return false;
    }
    return true;
  }

  /// Détermine le gagnant final en comptant les ibimari puis les points
  /// RETOURNE: l'ID du gagnant, ou '' si égalité (personne ne gagne)
  String _determineFinalWinner() {
    if (_gameState == null) return '';

    if (_gameState!.mode == GameMode.individual) {
      // Mode Individuel: compare les ibimari d'abord
      final playerScores = <String, int>{};
      final playerIbimari = <String, int>{};

      for (var player in _gameState!.players) {
        final hand = _gameState!.playerCards[player.id] ?? [];
        final ibimariCount = _countIbimari(hand);
        final pointsCount = _calculatePoints(hand);

        playerIbimari[player.id] = ibimariCount;
        playerScores[player.id] = pointsCount;
      }

      // Trouve le maximum d'ibimari
      int maxIbimari = 0;
      for (var count in playerIbimari.values) {
        if (count > maxIbimari) maxIbimari = count;
      }

      // Trouve les joueurs avec le max d'ibimari
      final playersWithMaxIbimari = playerIbimari.entries
          .where((e) => e.value == maxIbimari)
          .map((e) => e.key)
          .toList();

      // Si un seul joueur a le plus d'ibimari, il gagne
      if (playersWithMaxIbimari.length == 1) {
        return playersWithMaxIbimari.first;
      }

      // Égalité sur les ibimari: compare les points
      int maxPoints = -1;
      String winnerId = '';
      int countMaxPoints = 0;  // Pour compter combien ont le même max

      for (var playerId in playersWithMaxIbimari) {
        if (playerScores[playerId]! > maxPoints) {
          maxPoints = playerScores[playerId]!;
          winnerId = playerId;
          countMaxPoints = 1;
        } else if (playerScores[playerId]! == maxPoints) {
          countMaxPoints++;
        }
      }

      // Si plusieurs joueurs ont le même nombre de points, c'est une vraie égalité
      // Selon le plan: "En cas d'égalité, personne ne gagne"
      if (countMaxPoints > 1) {
        return '';  // Égalité - personne ne gagne
      }

      return winnerId;
    } else {
      // Mode Groupes: additionne les ibimari et points par équipe
      final teamScores = <String, int>{};
      final teamIbimari = <String, int>{};
      
      for (var player in _gameState!.players) {
        if (player.teamId != null) {
          final hand = _gameState!.playerCards[player.id] ?? [];
          final ibimariCount = _countIbimari(hand);
          final pointsCount = _calculatePoints(hand);
          
          teamIbimari[player.teamId!] = (teamIbimari[player.teamId!] ?? 0) + ibimariCount;
          teamScores[player.teamId!] = (teamScores[player.teamId!] ?? 0) + pointsCount;
        }
      }
      
      // Trouve le maximum d'ibimari
      int maxIbimari = 0;
      for (var count in teamIbimari.values) {
        if (count > maxIbimari) maxIbimari = count;
      }
      
      // Trouve les équipes avec le max d'ibimari
      final teamsWithMaxIbimari = teamIbimari.entries
          .where((e) => e.value == maxIbimari)
          .map((e) => e.key)
          .toList();
      
      // Si une seule équipe a le plus d'ibimari, elle gagne
      if (teamsWithMaxIbimari.length == 1) {
        return teamsWithMaxIbimari.first;
      }
      
      // Égalité sur les ibimari: compare les points
      int maxPoints = -1;
      String winnerId = '';
      int countMaxPoints = 0;  // Pour compter combien ont le même max

      for (var teamId in teamsWithMaxIbimari) {
        if (teamScores[teamId]! > maxPoints) {
          maxPoints = teamScores[teamId]!;
          winnerId = teamId;
          countMaxPoints = 1;
        } else if (teamScores[teamId]! == maxPoints) {
          countMaxPoints++;
        }
      }

      // Si plusieurs équipes ont le même nombre de points, c'est une vraie égalité
      // Selon le plan: "En cas d'égalité, personne ne gagne"
      if (countMaxPoints > 1) {
        return '';  // Égalité - personne ne gagne
      }

      return winnerId;
    }
  }
  
  /// Calcule les points d'une main
  int _calculatePoints(List<PlayingCard> hand) {
    int points = 0;
    for (var card in hand) {
      points += card.points;
    }
    return points;
  }

  /// Met à jour les DDK d'un joueur
  void updatePlayerDDK(String playerId, int amount) {
    if (_gameState == null) return;

    final updatedPlayers = _gameState!.players.map((p) {
      if (p.id == playerId) {
        return p.copyWith(ddkBalance: p.ddkBalance + amount);
      }
      return p;
    }).toList();

    _gameState = _gameState!.copyWith(players: updatedPlayers);
    _notifyListeners();
  }

  /// Annule la partie
  void cancelGame() {
    if (_gameState == null) return;

    _gameState = _gameState!.copyWith(status: GameStatus.cancelled);
    _notifyListeners();
  }

  /// Réinitialise la partie
  void resetGame() {
    if (_gameState == null) return;

    _gameState = _gameState!.copyWith(
      status: GameStatus.waiting,
      deck: _createDeck(),
      playerCards: {},
      strongSuit: null,
      currentPlayerIndex: 0,
      potAmount: 0,
      tableCards: [],
      trickNumber: 0,
      winnerId: null,
      message: null,
    );
    
    _currentTrickCards = null;
    _currentTrickPlayerIds = null;
    
    _notifyListeners();
  }
  
  /// Forme les équipes aléatoirement (pour Mode Groupes)
  /// CORRIGÉ: Vérifie si les équipes sont déjà formées pour éviter une re-randomisation
  void formTeams() {
    if (_gameState == null || _gameState!.players.length < 4) return;

    // CORRIGÉ: Vérifie si les équipes sont déjà formées
    final existingTeams = _gameState!.players
        .where((p) => p.teamId != null)
        .map((p) => p.teamId!)
        .toSet();
    if (existingTeams.isNotEmpty) {
      debugPrint('Les équipes sont déjà formées, pas de re-randomisation');
      return;  // Les équipes sont déjà formées, ne pas re-randomiser
    }

    final players = List<Player>.from(_gameState!.players);
    players.shuffle(Random());

    final teamCount = players.length == 4 ? 2 : 2; // 2 équipes de 2 ou 2 équipes de 3
    final playersPerTeam = players.length ~/ teamCount;

    final updatedPlayers = <Player>[];

    for (int i = 0; i < players.length; i++) {
      final teamIndex = i ~/ playersPerTeam;
      final teamId = 'team_${teamIndex + 1}';

      updatedPlayers.add(players[i].copyWith(teamId: teamId));
    }

    _gameState = _gameState!.copyWith(players: updatedPlayers);
    _notifyListeners();
  }

  /// Traite une action de jeu depuis le réseau (hôte uniquement)
  /// Cette méthode est appelée quand l'hôte reçoit une action d'un client
  void processGameActionFromNetwork(String playerId, String actionType, Map<String, dynamic>? actionData) {
    debugPrint('Traitement action réseau: $actionType par $playerId');

    switch (actionType) {
      case 'play_card':
        if (actionData != null) {
          final cardJson = actionData['card'] as Map<String, dynamic>?;
          if (cardJson != null) {
            final card = PlayingCard.fromJson(cardJson);
            playCardFromNetwork(playerId, card);
          }
        }
        break;

      case 'place_bet':
        if (actionData != null) {
          final amount = actionData['amount'] as int?;
          if (amount != null) {
            placeBet(amount);
          }
        }
        break;

      default:
        debugPrint('Action inconnue: $actionType');
    }
  }
}
