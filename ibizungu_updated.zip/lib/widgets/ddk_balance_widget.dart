import 'package:provider/provider.dart';
import '../utils/theme.dart';
import '../services/services.dart';

/// Widget d'affichage du solde DDK
class DdkBalanceWidget extends StatelessWidget {
  final int balance;
  final bool showAnimation;
  final VoidCallback? onTap;

  const DdkBalanceWidget({
    super.key,
    required this.balance,
    this.showAnimation = false,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final storageService = context.watch<StorageService>();
    final isAdmin = storageService.getAdminCode() != null && storageService.getAdminCode()!.isNotEmpty;

    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: BoxDecoration(
          color: isAdmin ? AppTheme.primaryGold.withValues(alpha: 0.1) : AppTheme.surfaceDark,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: isAdmin ? AppTheme.primaryGold : AppTheme.primaryGold.withValues(alpha: 0.3),
            width: isAdmin ? 2 : 1,
          ),
          boxShadow: [
            BoxShadow(
              color: AppTheme.primaryGold.withValues(alpha: 0.1),
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              isAdmin ? Icons.admin_panel_settings : Icons.monetization_on,
              color: AppTheme.primaryGold,
              size: 20,
            ),
            const SizedBox(width: 8),
            AnimatedSwitcher(
              duration: const Duration(milliseconds: 300),
              transitionBuilder: (child, animation) {
                return ScaleTransition(
                  scale: animation,
                  child: child,
                );
              },
              child: Text(
                '$balance',
                key: ValueKey(balance),
                style: const TextStyle(
                  color: AppTheme.primaryGold,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            const SizedBox(width: 4),
            Text(
              isAdmin ? 'DDK (Admin)' : 'DDK',
              style: const TextStyle(
                color: AppTheme.primaryGold,
                fontSize: 12,
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
