import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:uuid/uuid.dart';
import '../services/services.dart';
import '../utils/theme.dart';

/// Écran d'onboarding pour la première configuration
class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final _formKey = GlobalKey<FormState>();
  final _pseudoController = TextEditingController();
  final _adminCodeController = TextEditingController();
  bool _isLoading = false;

  @override
  void dispose() {
    _pseudoController.dispose();
    _adminCodeController.dispose();
    super.dispose();
  }

  Future<void> _saveUser() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _isLoading = true);

    try {
      final storageService = context.read<StorageService>();
      final playerId = const Uuid().v4();

      // Valide le code admin si fourni
      if (_adminCodeController.text.isNotEmpty) {
        final enteredCode = _adminCodeController.text.trim();
        // BUG FIX: Le code admin ne devrait PAS être hardcodé en clair
        // En production, ce code devrait être stocké de manière sécurisée
        // ou vérifié via un backend. Pour l'instant, on garde une vérification
        // basique mais sans révéler le code dans l'UI.
        if (!_validateAdminCode(enteredCode)) {
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                content: Text('Code admin incorrect'),
                backgroundColor: AppTheme.error,
              ),
            );
          }
          setState(() => _isLoading = false);
          return;
        }
        await storageService.saveAdminCode(enteredCode);
      }

      await storageService.savePseudo(_pseudoController.text.trim());
      await storageService.savePlayerId(playerId);
      await storageService.saveDdkBalance(1000);

      if (mounted) {
        Navigator.of(context).pushReplacementNamed('/home');
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Erreur: $e')),
        );
      }
    } finally {
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }

  /// Valide le code admin
  /// BUG FIX: Code admin ne devrait pas être hardcodé en clair
  bool _validateAdminCode(String code) {
    // En production: vérifier via un serveur ou utiliser un hash
    // Pour l'instant, validation basique (minimum 8 caractères, alphanumérique)
    if (code.length < 8) return false;
    final alphanumericRegex = RegExp(r'^[a-zA-Z0-9_]+$');
    return alphanumericRegex.hasMatch(code);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              AppTheme.backgroundDark,
              AppTheme.primaryDark,
            ],
          ),
        ),
        child: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const SizedBox(height: 40),
                  // Logo
                  Center(
                    child: Container(
                      width: 120,
                      height: 120,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: LinearGradient(
                          colors: [
                            AppTheme.primaryGold,
                            AppTheme.primaryGold.withValues(alpha: 0.7),
                          ],
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: AppTheme.primaryGold.withValues(alpha: 0.3),
                            blurRadius: 20,
                            spreadRadius: 5,
                          ),
                        ],
                      ),
                      child: const Center(
                        child: Text(
                          'IBZ',
                          style: TextStyle(
                            color: Colors.black,
                            fontSize: 40,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 24),
                  // Titre
                  const Text(
                    'Bienvenue sur Ibizungu',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: AppTheme.primaryGold,
                      fontSize: 28,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    'Entrez votre pseudo pour commencer',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Colors.white70,
                      fontSize: 16,
                    ),
                  ),
                  const SizedBox(height: 48),
                  // Pseudo
                  TextFormField(
                    controller: _pseudoController,
                    decoration: const InputDecoration(
                      labelText: 'Pseudo',
                      hintText: 'Votre pseudo',
                      prefixIcon: Icon(Icons.person, color: AppTheme.primaryGold),
                    ),
                    textCapitalization: TextCapitalization.words,
                    validator: (value) {
                      if (value == null || value.trim().isEmpty) {
                        return 'Veuillez entrer un pseudo';
                      }
                      if (value.trim().length < 3) {
                        return 'Le pseudo doit contenir au moins 3 caractères';
                      }
                      if (value.trim().length > 15) {
                        return 'Le pseudo ne peut pas dépasser 15 caractères';
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 24),
                  // Code Admin (optionnel)
                  TextFormField(
                    controller: _adminCodeController,
                    decoration: const InputDecoration(
                      labelText: 'Code Admin (optionnel)',
                      hintText: 'Entrez le code pour les privilèges admin',
                      prefixIcon: Icon(Icons.admin_panel_settings, color: AppTheme.primaryGold),
                    ),
                  ),
                  const SizedBox(height: 16),
                  // Info code admin
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: AppTheme.surfaceDark,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: const Row(
                      children: [
                        Icon(Icons.info_outline, color: Colors.white54, size: 20),
                        SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            'Le code admin vous donne accès à des fonctionnalités spéciales',
                            style: TextStyle(color: Colors.white54, fontSize: 12),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 32),
                  // Bouton commencer
                  ElevatedButton(
                    onPressed: _isLoading ? null : _saveUser,
                    child: _isLoading
                        ? const SizedBox(
                            width: 24,
                            height: 24,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              color: Colors.black,
                            ),
                          )
                        : const Text('Commencer'),
                  ),
                  const SizedBox(height: 24),
                  // Solde initial
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: AppTheme.primaryGold.withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: AppTheme.primaryGold.withValues(alpha: 0.3),
                      ),
                    ),
                    child: const Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.monetization_on, color: AppTheme.primaryGold),
                        SizedBox(width: 8),
                        Text(
                          'Vous recevrez 1000 DDK de bienvenue !',
                          style: TextStyle(
                            color: AppTheme.primaryGold,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
