import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/services.dart';
import '../utils/theme.dart';
import '../widgets/widgets.dart';

/// Écran d'accueil principal
class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );

    _fadeAnimation = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeOut),
    );

    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.2),
      end: Offset.zero,
    ).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeOut),
    );

    _animationController.forward();
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  void _handleDdkBalanceTap() {
    final storageService = context.read<StorageService>();
    final isAdmin = storageService.getAdminCode() != null && storageService.getAdminCode()!.isNotEmpty;

    if (isAdmin) {
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('Mode Admin : Ajouter des DDK'),
          content: const Text('Voulez-vous ajouter 1000 DDK à votre compte ?'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Annuler'),
            ),
            ElevatedButton(
              onPressed: () {
                final currentBalance = storageService.getDdkBalance();
                storageService.saveDdkBalance(currentBalance + 1000);
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('1000 DDK ajoutés (Admin)')),
                );
              },
              style: ElevatedButton.styleFrom(backgroundColor: AppTheme.primaryGold, foregroundColor: Colors.black),
              child: const Text('Ajouter 1000'),
            ),
          ],
        ),
      );
    } else {
      _showDdkExchangeDialog();
    }
  }

  void _showDdkExchangeDialog() {
    Navigator.of(context).pushNamed('/ddk-exchange');
  }

  void _showDdkTransferDialog() {
    Navigator.of(context).pushNamed('/ddk-transfer');
  }

  void _showReceiveDdkDialog() {
    Navigator.of(context).pushNamed('/receive-ddk');
  }

  void _createGame() {
    Navigator.of(context).pushNamed('/game-lobby', arguments: {'isHost': true});
  }

  void _joinGame() {
    Navigator.of(context).pushNamed('/game-lobby', arguments: {'isHost': false});
  }

  @override
  Widget build(BuildContext context) {
    final storageService = context.watch<StorageService>();
    final balance = storageService.getDdkBalance();
    final pseudo = storageService.getPseudo() ?? 'Joueur';

    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              AppTheme.backgroundDark,
              AppTheme.primaryDark,
            ],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              // Header - CORRIGÉ selon le plan: boutons en haut à droite
              Padding(
                padding: const EdgeInsets.all(16),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Menu hamburger à gauche
                    IconButton(
                      icon: const Icon(Icons.menu, color: AppTheme.primaryGold),
                      onPressed: () => Navigator.of(context).pushNamed('/settings'),
                    ),
                    // Colonne: Solde DDK + Boutons "Gagner de l'argent" et "Envoyer des DDK"
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        // Solde DDK
                        DdkBalanceWidget(
                          balance: balance,
                          onTap: _handleDdkBalanceTap,
                        ),                        const SizedBox(height: 8),
                        // Bouton "Gagner de l'argent" - EN HAUT À DROITE
                        _buildTopActionButton(
                          icon: Icons.trending_up,
                          label: 'Gagner de l\'argent',
                          onTap: () {
                            showDialog(
                              context: context,
                              builder: (context) => AlertDialog(
                                backgroundColor: AppTheme.surfaceDark,
                                title: const Text('Service en maintenance', style: TextStyle(color: AppTheme.primaryGold)),
                                content: const Text(
                                  'L\'option "Gagner de l\'argent" est actuellement en maintenance. Elle sera disponible dans la seconde version de l\'application.',
                                  style: TextStyle(color: Colors.white70),
                                ),
                                actions: [
                                  TextButton(
                                    onPressed: () => Navigator.pop(context),
                                    child: const Text('OK', style: TextStyle(color: AppTheme.primaryGold)),
                                  ),
                                ],
                              ),
                            );
                          },
                        ),
                        const SizedBox(height: 4),
                        // Bouton "Envoyer des DDK" - JUSTE EN DESSOUS
                        _buildTopActionButton(
                          icon: Icons.send,
                          label: 'Envoyer des DDK',
                          onTap: _showDdkTransferDialog,
                        ),
                      ],
                    ),
                  ],
                ),
              ),

              Expanded(
                child: FadeTransition(
                  opacity: _fadeAnimation,
                  child: SlideTransition(
                    position: _slideAnimation,
                    child: SingleChildScrollView(
                      padding: const EdgeInsets.all(24),
                      child: Column(
                        children: [
                          const SizedBox(height: 20),
                          // Logo
                          _buildLogo(),
                          const SizedBox(height: 40),
                          // Message de bienvenue
                          Text(
                            'Bienvenue, $pseudo!',
                            style: Theme.of(context).textTheme.headlineMedium,
                          ),
                          const SizedBox(height: 40),
                          // Bouton Jouer
                          _buildMainButton(
                            icon: Icons.play_arrow,
                            label: 'Jouer',
                            onTap: _showGameModeDialog,
                            isPrimary: true,
                          ),
                          const SizedBox(height: 16),
                          // Bouton Historique
                          _buildMainButton(
                            icon: Icons.history,
                            label: 'Historique',
                            onTap: () => Navigator.of(context).pushNamed('/history'),
                          ),
                          const SizedBox(height: 16),
                          // Bouton Acheter des DDK
                          _buildMainButton(
                            icon: Icons.add_circle,
                            label: 'Acheter des DDK',
                            onTap: () => Navigator.of(context).pushNamed('/buy-ddk'),
                          ),
                          const SizedBox(height: 40),
                          // Actions rapides
                          _buildQuickActions(),
                          const SizedBox(height: 24),
                          // Bouton À propos
                          TextButton.icon(
                            icon: const Icon(Icons.info_outline),
                            label: const Text('À propos'),
                            onPressed: () => Navigator.of(context).pushNamed('/about'),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildLogo() {
    return Container(
      width: 140,
      height: 140,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: Colors.black,
        border: Border.all(
          color: AppTheme.primaryGold,
          width: 3,
        ),
        boxShadow: [
          BoxShadow(
            color: AppTheme.primaryGold.withValues(alpha: 0.4),
            blurRadius: 30,
            spreadRadius: 5,
          ),
        ],
      ),
      child: const Center(
        child: Text(
          'I',
          style: TextStyle(
            color: AppTheme.primaryGold,
            fontSize: 80,
            fontWeight: FontWeight.bold,
            fontFamily: 'Serif',
          ),
        ),
      ),
    );
  }

  Widget _buildMainButton({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
    bool isPrimary = false,
  }) {
    return SizedBox(
      width: double.infinity,
      child: isPrimary
          ? ElevatedButton.icon(
              icon: Icon(icon, size: 28),
              label: Text(
                label,
                style: const TextStyle(fontSize: 20),
              ),
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 20),
              ),
              onPressed: onTap,
            )
          : OutlinedButton.icon(
              icon: Icon(icon, size: 24),
              label: Text(
                label,
                style: const TextStyle(fontSize: 18),
              ),
              style: OutlinedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 16),
              ),
              onPressed: onTap,
            ),
    );
  }

  /// Bouton d'action en haut (Gagner de l'argent / Envoyer des DDK)
  Widget _buildTopActionButton({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(8),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(
          color: AppTheme.primaryGold.withValues(alpha: 0.15),
          borderRadius: BorderRadius.circular(8),
          border: Border.all(
            color: AppTheme.primaryGold.withValues(alpha: 0.3),
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, color: AppTheme.primaryGold, size: 16),
            const SizedBox(width: 6),
            Text(
              label,
              style: const TextStyle(
                color: AppTheme.primaryGold,
                fontSize: 12,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildQuickActions() {
    // Actions rapides - UNIQUEMENT "Recevoir des DDK"
    // "Gagner de l'argent" et "Envoyer des DDK" sont maintenant en haut à droite
    return Row(
      children: [
        Expanded(
          child: _buildQuickActionButton(
            icon: Icons.qr_code_scanner,
            label: 'Recevoir\ndes DDK',
            onTap: _showReceiveDdkDialog,
            color: Colors.purple,
          ),
        ),
      ],
    );
  }

  Widget _buildQuickActionButton({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
    required Color color,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 12),
        decoration: BoxDecoration(
          color: color.withValues(alpha: 0.1),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: color.withValues(alpha: 0.3),
          ),
        ),
        child: Column(
          children: [
            Icon(icon, color: color, size: 28),
            const SizedBox(height: 8),
            Text(
              label,
              textAlign: TextAlign.center,
              style: TextStyle(
                color: color,
                fontSize: 12,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showGameModeDialog() {
    showDialog(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Mode de jeu'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Bouton pour REJOINDRE une partie (CLIENT)
            ListTile(
              leading: const Icon(Icons.wifi, color: Colors.lightBlue),
              title: const Text('Rejoindre une partie'),
              subtitle: const Text('Scanner QR, réseau ou IP'),
              onTap: () {
                Navigator.pop(dialogContext);
                Navigator.of(context).pushNamed(
                  '/game-lobby',
                  arguments: {'isHost': false},
                );
              },
            ),
            const Divider(),
            // Bouton pour CRÉER une partie (HÔTE)
            ListTile(
              leading: const Icon(Icons.person, color: AppTheme.primaryGold),
              title: const Text('Mode Individuel'),
              subtitle: const Text('3 ou 4 joueurs'),
              onTap: () {
                Navigator.pop(dialogContext);
                Navigator.of(context).pushNamed(
                  '/game-lobby',
                  arguments: {'isHost': true, 'mode': 'individual'},
                );
              },
            ),
            // Mode Groupes - SEULEMENT pour 4 ou 6 joueurs
            ListTile(
              leading: const Icon(Icons.groups, color: AppTheme.primaryGold),
              title: const Text('Mode Groupes'),
              subtitle: const Text('Équipes de 2-3 (4 ou 6 joueurs)'),
              onTap: () {
                Navigator.pop(dialogContext);
                Navigator.of(context).pushNamed(
                  '/game-lobby',
                  arguments: {'isHost': true, 'mode': 'groups'},
                );
              },
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text('Annuler'),
          ),
        ],
      ),
    );
  }
}
