import 'dart:io';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:image_picker/image_picker.dart';
import '../services/services.dart';
import '../utils/theme.dart';

/// Offres d'achat DDK
class DdkOffer {
  final int fbuAmount;
  final int ddkAmount;
  final String description;

  const DdkOffer({
    required this.fbuAmount,
    required this.ddkAmount,
    required this.description,
  });
}

/// Écran d'achat de DDK via Mobile Money (Lumicash)
class BuyDdkScreen extends StatefulWidget {
  const BuyDdkScreen({super.key});

  @override
  State<BuyDdkScreen> createState() => _BuyDdkScreenState();
}

class _BuyDdkScreenState extends State<BuyDdkScreen> {
  // Numéro Lumicash pour recevoir les paiements
  static const String lumicashNumber = '67884228';

  // Offres disponibles
  static const List<DdkOffer> offers = [
    DdkOffer(fbuAmount: 500, ddkAmount: 500, description: 'Pack Débutant'),
    DdkOffer(fbuAmount: 1000, ddkAmount: 1000, description: 'Pack Standard'),
    DdkOffer(fbuAmount: 1500, ddkAmount: 1500, description: 'Pack Premium'),
    DdkOffer(fbuAmount: 2000, ddkAmount: 2000, description: 'Pack VIP'),
  ];

  DdkOffer? _selectedOffer;
  File? _proofImage;
  bool _isProcessing = false;
  String? _verificationResult;
  bool _isVerified = false;
  final OnlineOcrService _ocrService = OnlineOcrService();

  final ImagePicker _picker = ImagePicker();

  @override
  void dispose() {
    // OnlineOcrService n'a pas de ressources à libérer
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final storageService = context.watch<StorageService>();
    final balance = storageService.getDdkBalance();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Acheter des DDK'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              AppTheme.backgroundDark,
              AppTheme.primaryDark,
            ],
          ),
        ),
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Solde actuel
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.account_balance_wallet, color: AppTheme.primaryGold),
                      const SizedBox(width: 12),
                      Text(
                        'Solde actuel: $balance DDK',
                        style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 24),

              // Instructions
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: AppTheme.primaryGold.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: AppTheme.primaryGold.withValues(alpha: 0.3)),
                ),
                child: const Column(
                  children: [
                    Icon(Icons.info_outline, color: AppTheme.primaryGold, size: 32),
                    SizedBox(height: 12),
                    Text(
                      'Comment acheter des DDK',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: AppTheme.primaryGold,
                      ),
                    ),
                    SizedBox(height: 8),
                    Text(
                      '1. Sélectionnez un pack ci-dessous\n'
                      '2. Envoyez l\'argent au numéro Lumicash\n'
                      '3. Prenez une capture du SMS de confirmation\n'
                      '4. Uploadez la capture pour recevoir vos DDK',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.white70, height: 1.5),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24),

              // Offres
              const Text(
                'Choisissez un pack',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 16),

              ...offers.map((offer) => _buildOfferCard(offer)),

              // Numéro Lumicash (apparaît après sélection)
              if (_selectedOffer != null) ...[
                const SizedBox(height: 24),
                _buildLumicashPaymentSection(),
              ],

              // Upload preuve (apparaît après sélection)
              if (_selectedOffer != null) ...[
                const SizedBox(height: 24),
                _buildProofUploadSection(),
              ],

              // Résultat vérification
              if (_verificationResult != null) ...[
                const SizedBox(height: 24),
                _buildVerificationResult(),
              ],

              const SizedBox(height: 32),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildOfferCard(DdkOffer offer) {
    final isSelected = _selectedOffer == offer;

    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: InkWell(
        onTap: () {
          setState(() {
            _selectedOffer = offer;
            _proofImage = null;
            _verificationResult = null;
            _isVerified = false;
          });
        },
        borderRadius: BorderRadius.circular(12),
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: isSelected
                ? AppTheme.primaryGold.withValues(alpha: 0.2)
                : AppTheme.surfaceDark,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: isSelected
                  ? AppTheme.primaryGold
                  : Colors.transparent,
              width: 2,
            ),
          ),
          child: Row(
            children: [
              Container(
                width: 60,
                height: 60,
                decoration: BoxDecoration(
                  color: AppTheme.primaryGold.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Center(
                  child: Text(
                    '${offer.ddkAmount}',
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: AppTheme.primaryGold,
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      offer.description,
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '${offer.fbuAmount} FBU → ${offer.ddkAmount} DDK',
                      style: const TextStyle(
                        color: Colors.white70,
                      ),
                    ),
                  ],
                ),
              ),
              if (isSelected)
                const Icon(Icons.check_circle, color: AppTheme.primaryGold)
              else
                const Icon(Icons.circle_outlined, color: Colors.white38),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildLumicashPaymentSection() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppTheme.success.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppTheme.success.withValues(alpha: 0.3)),
      ),
      child: Column(
        children: [
          const Icon(Icons.phone_android, color: AppTheme.success, size: 40),
          const SizedBox(height: 12),
          const Text(
            'Envoyez l\'argent à',
            style: TextStyle(color: Colors.white70),
          ),
          const SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text(
                'Lumicash: ',
                style: TextStyle(fontSize: 16),
              ),
              Text(
                lumicashNumber,
                style: const TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: AppTheme.success,
                  letterSpacing: 2,
                ),
              ),
              IconButton(
                icon: const Icon(Icons.copy, color: AppTheme.success),
                onPressed: () {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Numéro copié !')),
                  );
                },
              ),
            ],
          ),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Text('Montant à envoyer: '),
                Text(
                  '${_selectedOffer!.fbuAmount} FBU',
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    color: AppTheme.success,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          const Text(
            'Après envoi, prenez une capture du SMS\nde confirmation LUMITEL',
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.white70, fontSize: 12),
          ),
        ],
      ),
    );
  }

  Widget _buildProofUploadSection() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppTheme.surfaceDark,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        children: [
          const Icon(Icons.receipt_long, color: AppTheme.primaryGold, size: 40),
          const SizedBox(height: 12),
          const Text(
            'Preuve de transaction',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            'Uploadez une capture du SMS de LUMITEL\nconfirmant votre transaction',
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.white70, fontSize: 12),
          ),
          const SizedBox(height: 16),

          // Zone d'upload
          if (_proofImage == null)
            InkWell(
              onTap: _pickImage,
              borderRadius: BorderRadius.circular(12),
              child: Container(
                height: 150,
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: 0.05),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: AppTheme.primaryGold.withValues(alpha: 0.3),
                    style: BorderStyle.solid,
                  ),
                ),
                child: const Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.add_photo_alternate,
                           color: AppTheme.primaryGold, size: 48),
                      SizedBox(height: 8),
                      Text(
                        'Cliquez pour ajouter une photo',
                        style: TextStyle(color: Colors.white54),
                      ),
                    ],
                  ),
                ),
              ),
            )
          else
            Stack(
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(12),
                  child: Image.file(
                    _proofImage!,
                    height: 200,
                    width: double.infinity,
                    fit: BoxFit.cover,
                  ),
                ),
                Positioned(
                  top: 8,
                  right: 8,
                  child: IconButton(
                    icon: const Icon(Icons.close, color: Colors.white),
                    style: IconButton.styleFrom(
                      backgroundColor: Colors.black54,
                    ),
                    onPressed: () {
                      setState(() {
                        _proofImage = null;
                        _verificationResult = null;
                        _isVerified = false;
                      });
                    },
                  ),
                ),
              ],
            ),

          const SizedBox(height: 16),

          // Bouton vérifier avec OCR
          if (_proofImage != null && !_isVerified)
            ElevatedButton.icon(
              icon: _isProcessing
                  ? const SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : const Icon(Icons.verified_user),
              label: const Text('Vérifier la transaction'),
              onPressed: _isProcessing ? null : _verifyTransaction,
            ),
        ],
      ),
    );
  }

  Widget _buildVerificationResult() {
    final isSuccess = _isVerified;

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: isSuccess
            ? AppTheme.success.withValues(alpha: 0.1)
            : AppTheme.error.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: isSuccess
              ? AppTheme.success.withValues(alpha: 0.3)
              : AppTheme.error.withValues(alpha: 0.3),
        ),
      ),
      child: Column(
        children: [
          Icon(
            isSuccess ? Icons.check_circle : Icons.error,
            color: isSuccess ? AppTheme.success : AppTheme.error,
            size: 48,
          ),
          const SizedBox(height: 12),
          Text(
            isSuccess ? 'Transaction vérifiée !' : 'Vérification échouée',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: isSuccess ? AppTheme.success : AppTheme.error,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            _verificationResult!,
            textAlign: TextAlign.center,
            style: const TextStyle(color: Colors.white70),
          ),
          const SizedBox(height: 16),

          if (isSuccess)
            ElevatedButton.icon(
              icon: const Icon(Icons.add_circle),
              label: Text('Recevoir ${_selectedOffer!.ddkAmount} DDK'),
              onPressed: _creditDDK,
              style: ElevatedButton.styleFrom(
                backgroundColor: AppTheme.success,
              ),
            ),
        ],
      ),
    );
  }

  Future<void> _pickImage() async {
    // Permettre de prendre une photo ou choisir dans la galerie
    final source = await showModalBottomSheet<ImageSource>(
      context: context,
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.camera_alt),
              title: const Text('Prendre une photo'),
              onTap: () => Navigator.pop(context, ImageSource.camera),
            ),
            ListTile(
              leading: const Icon(Icons.photo_library),
              title: const Text('Choisir dans la galerie'),
              onTap: () => Navigator.pop(context, ImageSource.gallery),
            ),
          ],
        ),
      ),
    );

    if (source == null) return;

    try {
      final XFile? image = await _picker.pickImage(
        source: source,
        imageQuality: 80,
      );

      if (image != null) {
        setState(() {
          _proofImage = File(image.path);
          _verificationResult = null;
          _isVerified = false;
        });
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Erreur: $e')),
        );
      }
    }
  }

  /// Vérifie la transaction en utilisant l'OCR réel
  Future<void> _verifyTransaction() async {
    if (_proofImage == null || _selectedOffer == null) return;

    setState(() => _isProcessing = true);

    try {
      // Utilise le service OCR pour vérifier le message Lumitel
      final (isValid, message) = await _ocrService.verifyLumitelTransaction(
        _proofImage!,
        _selectedOffer!.fbuAmount,
      );

      setState(() {
        if (isValid) {
          _verificationResult = message;
          _isVerified = true;
        } else {
          _verificationResult = message;
          _isVerified = false;
        }
      });

    } catch (e) {
      setState(() {
        _verificationResult = 'Erreur lors de l\'analyse de l\'image.\n'
            'Veuillez réessayer avec une capture plus claire.';
        _isVerified = false;
      });
    } finally {
      setState(() => _isProcessing = false);
    }
  }

  Future<void> _creditDDK() async {
    if (_selectedOffer == null) return;

    final storageService = context.read<StorageService>();
    final currentBalance = storageService.getDdkBalance();
    final newBalance = currentBalance + _selectedOffer!.ddkAmount;

    await storageService.saveDdkBalance(newBalance);

    if (mounted) {
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: const Row(
            children: [
              Icon(Icons.check_circle, color: AppTheme.success),
              SizedBox(width: 8),
              Text('Félicitations !'),
            ],
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.celebration, color: AppTheme.primaryGold, size: 64),
              const SizedBox(height: 16),
              Text(
                '${_selectedOffer!.ddkAmount} DDK',
                style: const TextStyle(
                  fontSize: 32,
                  fontWeight: FontWeight.bold,
                  color: AppTheme.primaryGold,
                ),
              ),
              const Text('ont été ajoutés à votre compte !'),
              const SizedBox(height: 16),
              Text(
                'Nouveau solde: $newBalance DDK',
                style: const TextStyle(color: Colors.white70),
              ),
            ],
          ),
          actions: [
            ElevatedButton(
              onPressed: () {
                Navigator.pop(context);
                Navigator.pop(context);
              },
              child: const Text('OK'),
            ),
          ],
        ),
      );
    }
  }
}
