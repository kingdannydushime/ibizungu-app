import 'package:flutter/material.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:provider/provider.dart';
import '../services/services.dart';
import '../utils/theme.dart';
import '../utils/helpers.dart';

/// Écran pour recevoir des DDK via scan de QR Code
class ReceiveDdkScreen extends StatefulWidget {
  const ReceiveDdkScreen({super.key});

  @override
  State<ReceiveDdkScreen> createState() => _ReceiveDdkScreenState();
}

class _ReceiveDdkScreenState extends State<ReceiveDdkScreen> {
  MobileScannerController? _scannerController;
  bool _isProcessing = false;
  String? _lastScannedCode;
  String? _transferInfo;
  String? _senderPseudo;  // Pour afficher le nom de l'expéditeur

  static const int transferAmount = 50;

  @override
  void initState() {
    super.initState();
    _initScanner();
  }

  void _initScanner() {
    _scannerController = MobileScannerController(
      detectionSpeed: DetectionSpeed.normal,
      facing: CameraFacing.back,
    );
  }

  @override
  void dispose() {
    _scannerController?.dispose();
    super.dispose();
  }

  void _onDetect(BarcodeCapture capture) {
    if (_isProcessing) return;

    final List<Barcode> barcodes = capture.barcodes;
    if (barcodes.isEmpty) return;

    final String? code = barcodes.first.rawValue;
    if (code == null || code == _lastScannedCode) return;

    setState(() {
      _lastScannedCode = code;
      _isProcessing = true;
    });

    _processTransferCode(code);
  }

  Future<void> _processTransferCode(String code) async {
    // Parse le code de transfert
    final data = Helpers.parseDDKTransferCode(code);
    if (data == null) {
      _showError('Code QR invalide');
      return;
    }

    // Vérifie si le code n'est pas expiré (2 minutes)
    final timestamp = data['timestamp'] as int;
    if (Helpers.isTransferCodeExpired(timestamp)) {
      _showError('Ce code a expiré. Demandez un nouveau code à l\'expéditeur.');
      return;
    }

    // Vérifie que le montant est correct (50 DDK)
    final amount = data['amount'] as int;
    if (amount != transferAmount) {
      _showError('Montant invalide. Attendu: $transferAmount DDK');
      return;
    }

    final senderId = data['senderId'] as String;
    final senderPseudo = data['senderPseudo'] as String? ?? '';

    // Affiche les informations du transfert
    setState(() {
      _transferInfo = 'Code valide!\n$transferAmount DDK disponibles';
      _senderPseudo = senderPseudo;
    });

    // Crédite les DDK au destinataire
    await _creditDDK(senderId, senderPseudo);
  }

  Future<void> _creditDDK(String senderId, String senderPseudo) async {
    final storageService = context.read<StorageService>();
    final currentBalance = storageService.getDdkBalance();
    final newBalance = currentBalance + transferAmount;

    await storageService.saveDdkBalance(newBalance);

    if (mounted) {
      _showSuccess(newBalance, senderPseudo);
    }
  }

  void _showError(String message) {
    setState(() => _isProcessing = false);
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(message),
          backgroundColor: AppTheme.error,
        ),
      );
    }
  }

  void _showSuccess(int newBalance, String senderPseudo) {
    final senderText = senderPseudo.isNotEmpty
        ? ' de $senderPseudo'
        : '';
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Row(
          children: [
            Icon(Icons.check_circle, color: AppTheme.success),
            SizedBox(width: 8),
            Text('DDK reçus !'),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(
              Icons.add_circle,
              color: AppTheme.success,
              size: 64,
            ),
            const SizedBox(height: 16),
            Text(
              '+$transferAmount DDK',
              style: const TextStyle(
                fontSize: 32,
                fontWeight: FontWeight.bold,
                color: AppTheme.success,
              ),
            ),
            Text('ont été ajoutés à votre compte$senderText !'),
            const SizedBox(height: 16),
            Text(
              'Nouveau solde: $newBalance DDK',
              style: const TextStyle(color: Colors.white70),
            ),
          ],
        ),
        actions: [
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.pop(context);
            },
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  void _resetScanner() {
    setState(() {
      _isProcessing = false;
      _lastScannedCode = null;
      _transferInfo = null;
    });
  }

  @override
  Widget build(BuildContext context) {
    final storageService = context.watch<StorageService>();
    final balance = storageService.getDdkBalance();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Recevoir des DDK'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              AppTheme.backgroundDark,
              AppTheme.primaryDark,
            ],
          ),
        ),
        child: Column(
          children: [
            // Solde actuel
            Container(
              padding: const EdgeInsets.all(16),
              width: double.infinity,
              color: AppTheme.surfaceDark,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.account_balance_wallet, color: AppTheme.primaryGold),
                  const SizedBox(width: 12),
                  Text(
                    'Solde: ${Helpers.formatDDK(balance)}',
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),

            // Instructions
            Container(
              padding: const EdgeInsets.all(16),
              margin: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: AppTheme.primaryGold.withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: AppTheme.primaryGold.withValues(alpha: 0.3)),
              ),
              child: Column(
                children: [
                  Icon(Icons.qr_code_scanner, color: AppTheme.primaryGold, size: 32),
                  SizedBox(height: 12),
                  Text(
                    'Scanner le QR Code',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: AppTheme.primaryGold,
                    ),
                  ),
                  SizedBox(height: 8),
                  Text(
                    'Demandez à l\'expéditeur de vous montrer son QR Code et scannez-le pour recevoir $transferAmount DDK.',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.white70),
                  ),
                ],
              ),
            ),

            // Camera scanner
            Expanded(
              child: Container(
                margin: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(
                    color: AppTheme.primaryGold.withValues(alpha: 0.5),
                    width: 2,
                  ),
                ),
                clipBehavior: Clip.hardEdge,
                child: _scannerController != null
                    ? MobileScanner(
                        controller: _scannerController!,
                        onDetect: _onDetect,
                      )
                    : Center(
                        child: CircularProgressIndicator(),
                      ),
              ),
            ),

            // Statut du scan
            if (_isProcessing || _transferInfo != null)
              Container(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    if (_isProcessing && _transferInfo == null)
                      CircularProgressIndicator(),
                    if (_transferInfo != null)
                      Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: AppTheme.success.withValues(alpha: 0.2),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(
                          _transferInfo!,
                          textAlign: TextAlign.center,
                          style: TextStyle(color: AppTheme.success),
                        ),
                      ),
                  ],
                ),
              ),

            // Bouton reinitialiser
            Padding(
              padding: const EdgeInsets.all(16),
              child: TextButton.icon(
                icon: const Icon(Icons.refresh),
                label: const Text('Reinitialiser le scanner'),
                onPressed: _resetScanner,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
