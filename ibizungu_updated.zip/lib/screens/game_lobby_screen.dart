import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:uuid/uuid.dart';
import '../models/models.dart';
import '../services/services.dart';
import '../services/multiplayer/network_discovery_service.dart';
import '../utils/theme.dart';
import '../widgets/widgets.dart';

/// Écran de lobby de jeu
class GameLobbyScreen extends StatefulWidget {
  const GameLobbyScreen({super.key});

  @override
  State<GameLobbyScreen> createState() => _GameLobbyScreenState();
}

class _GameLobbyScreenState extends State<GameLobbyScreen> {
  final _roomCodeController = TextEditingController();
  final _ipController = TextEditingController();
  WiFiService? _wifiService;
  WiFiService? _tempWifiService; // BUG FIX: Pour disposer correctement
  GameService? _gameService;
  bool _isHost = false;
  GameMode _gameMode = GameMode.individual;
  int _playerCount = 4;
  String? _roomCode;
  String? _localIp;
  List<Player> _players = [];
  bool _isLoading = false;
  double _betAmount = 50.0;
  static const double _minBet = 50.0;
  static const double _maxBet = 500.0;

  // ======= Network Scanning State =======
  bool _isScanningNetwork = false;
  List<DiscoveredRoom> _scannedRooms = [];
  String? _selectedSubnet;

  @override
  void initState() {
    super.initState();
    _loadLocalIp();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();

    // Obtenir les services du Provider pour partager l'état entre joueurs
    _wifiService = context.read<WiFiService>();
    _gameService = context.read<GameService>();

    _wifiService!.addPlayerJoinedListener(_onPlayerJoined);
    _wifiService!.addPlayerLeftListener(_onPlayerLeft);
    _wifiService!.addGameStateListener(_onRemoteGameState);

    // Écouter les changements d'état du GameService
    _gameService!.addStateListener(_onLocalGameStateChanged);

    // Configure les callbacks pour le WiFiService
    _setupNetworkCallbacks();

    // Gère les arguments de route
    final args = ModalRoute.of(context)?.settings.arguments as Map<String, dynamic>?;
    if (args != null) {
      _isHost = args['isHost'] ?? false;
      if (args['mode'] == 'groups') {
        _gameMode = GameMode.groups;
      }
    }
  }

  void _setupNetworkCallbacks() {
    // Configure le callback pour les actions de jeu des clients (hôte uniquement)
    if (_wifiService != null && _gameService != null) {
      // Définir le callback de game action sur le WiFiService
      // pour transmettre les actions au GameService
      _wifiService!.setGameActionCallback((playerId, actionType, actionData) {
        debugPrint('Action reçue de $playerId: $actionType');
        _gameService!.processGameActionFromNetwork(playerId, actionType, actionData);
      });
    }
  }

  void _onRemoteGameState(GameState state) {
    // Synchroniser l'état du jeu reçu depuis l'hôte
    if (mounted) {
      setState(() {
        _players = List.from(state.players);
      });
      
      // BUG FIX: Naviguer vers l'écran de jeu si la partie a commencé
      if (state.status == GameStatus.playing) {
        // Met à jour le GameService local avec l'état complet
        _gameService?.updateFromRemote(state);
        
        // Navigue vers l'écran de jeu
        Navigator.of(context).pushReplacementNamed('/game');
      }
    }
  }

  void _onLocalGameStateChanged(GameState state) {
    // Mettre à jour la liste des joueurs depuis le GameService local
    if (mounted) {
      setState(() {
        _players = List.from(state.players);
      });
    }
  }

  Future<void> _loadLocalIp() async {
    // BUG FIX: Utiliser un service temporaire pour obtenir l'IP
    // et le disposer correctement après usage
    try {
      _tempWifiService = WiFiService();
      final ip = await _tempWifiService!.getLocalIpAddress();
      if (mounted) {
        setState(() {
          _localIp = ip ?? '127.0.0.1';
          if (ip != null) {
            final parts = ip.split('.');
            _selectedSubnet = '${parts[0]}.${parts[1]}.${parts[2]}';
          }
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _localIp = '127.0.0.1';
          _selectedSubnet = '192.168.1';
        });
      }
    } finally {
      // BUG FIX: Disposer le service temporaire après usage
      _tempWifiService?.dispose();
      _tempWifiService = null;
    }
  }

  /// Démarre le scan réseau pour trouver des salles
  Future<void> _startNetworkScan() async {
    if (_wifiService == null) return;

    setState(() {
      _isScanningNetwork = true;
      _scannedRooms.clear();
    });

    // Scan UDP broadcast d'abord
    await _wifiService!.startNetworkScan();

    // Attend un peu, puis scan TCP en parallèle
    await Future.delayed(const Duration(seconds: 2));

    if (_selectedSubnet != null) {
      // Lance le scan TCP en arrière-plan
      final rooms = await _wifiService!.scanNetworkRange(_selectedSubnet!);
      if (mounted) {
        setState(() {
          for (var room in rooms) {
            if (!_scannedRooms.any((r) => r.ipAddress == room.ipAddress)) {
              _scannedRooms.add(room);
            }
          }
        });
      }
    }

    // Arrête le scan UDP
    _wifiService!.stopNetworkScan();

    setState(() => _isScanningNetwork = false);
  }

  @override
  void dispose() {
    // Supprimer les listeners seulement si les services sont initialisés
    _wifiService?.removePlayerJoinedListener(_onPlayerJoined);
    _wifiService?.removePlayerLeftListener(_onPlayerLeft);
    _wifiService?.removeGameStateListener(_onRemoteGameState);
    _gameService?.removeStateListener(_onLocalGameStateChanged);
    _wifiService?.leaveRoom();
    _roomCodeController.dispose();
    _ipController.dispose();
    super.dispose();
  }

  void _onPlayerJoined(Player player) {
    setState(() {
      if (!_players.any((p) => p.id == player.id)) {
        _players.add(player);
      }
    });
    // Ajouter aussi au GameService si disponible
    _gameService?.addPlayer(player);
  }

  void _onPlayerLeft(String playerId) {
    setState(() {
      _players.removeWhere((p) => p.id == playerId);
    });
    // Retirer aussi du GameService si disponible
    _gameService?.removePlayer(playerId);
  }

  Future<void> _createRoom() async {
    if (_wifiService == null || _gameService == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Erreur: Services non initialisés')),
      );
      return;
    }

    setState(() => _isLoading = true);

    try {
      final storageService = context.read<StorageService>();
      final pseudo = storageService.getPseudo() ?? 'Hôte';
      final playerId = storageService.getPlayerId() ?? const Uuid().v4();

      _roomCode = WiFiService.generateRoomCode();

      final host = Player(
        id: playerId,
        pseudo: pseudo,
        ddkBalance: storageService.getDdkBalance(),
        isHost: true,
      );

      final success = await _wifiService!.createRoom(_roomCode!, host);

      if (success) {
        // Met à jour l'état local
        _isHost = true;

        // Initialise le WiFiService avec l'hôte
        _wifiService!.init(host);

        // Attend un peu pour que le serveur soit prêt
        await Future.delayed(const Duration(milliseconds: 500));

        await _loadLocalIp();

        setState(() {
          _players = [host];
        });

        _gameService!.createGame(
          roomCode: _roomCode!,
          host: host,
          mode: _gameMode,
          initialBet: _betAmount.round(),
        );

        // BUG FIX: Configurer le callback de broadcast UNIQUEMENT sur le GameService
        // Le callback sur WiFiService n'est pas nécessaire car GameService broadcasting
        // est automatiquement géré quand _broadcastState() est appelé
        _gameService!.setBroadcastCallback((state) {
          _wifiService!.broadcastGameState(state);
        });
      } else {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Erreur lors de la création de la salle')),
          );
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Erreur: $e')),
        );
      }
    } finally {
      setState(() => _isLoading = false);
    }
  }

  Future<void> _joinRoomWithData(String hostIp, int port, String roomCode) async {
    if (_wifiService == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Erreur: Service WiFi non initialisé')),
      );
      return;
    }

    setState(() => _isLoading = true);

    try {
      final storageService = context.read<StorageService>();
      final pseudo = storageService.getPseudo() ?? 'Joueur';
      final playerId = storageService.getPlayerId() ?? const Uuid().v4();

      // Mise à jour de l'état local
      _isHost = false;
      _roomCode = roomCode;

      final localPlayer = Player(
        id: playerId,
        pseudo: pseudo,
        ddkBalance: storageService.getDdkBalance(),
      );

      // CORRIGÉ: Initialiser AVANT joinRoom pour préparer la liste locale
      _wifiService!.init(localPlayer);

      final success = await _wifiService!.joinRoom(
        hostIp,
        port,
        roomCode,
        localPlayer,
      );

      if (success) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Connecté à la salle !')),
          );
        }
      } else {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Impossible de rejoindre la salle. Vérifiez l\'IP et le code.')),
          );
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Erreur: $e')),
        );
      }
    } finally {
      setState(() => _isLoading = false);
    }
  }

  Future<void> _showJoinDialog() async {
    // Reset controllers
    _roomCodeController.clear();
    _ipController.clear();

    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => StatefulBuilder(
        builder: (context, setModalState) {
          return Container(
            height: MediaQuery.of(context).size.height * 0.7,
            decoration: const BoxDecoration(
              color: AppTheme.backgroundDark,
              borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
            ),
            child: Column(
              children: [
                // Handle
                Container(
                  margin: const EdgeInsets.only(top: 12),
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Colors.white30,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
                // Title
                Padding(
                  padding: const EdgeInsets.all(20),
                  child: Row(
                    children: [
                      const Icon(Icons.wifi, color: AppTheme.primaryGold, size: 28),
                      const SizedBox(width: 12),
                      const Expanded(
                        child: Text(
                          'Rejoindre une partie',
                          style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                        ),
                      ),
                      IconButton(
                        icon: const Icon(Icons.close, color: Colors.white70),
                        onPressed: () => Navigator.pop(context),
                      ),
                    ],
                  ),
                ),
                const Divider(color: Colors.white12),
                // Options
                Expanded(
                  child: DefaultTabController(
                    length: 3,
                    child: Column(
                      children: [
                        const TabBar(
                          indicatorColor: AppTheme.primaryGold,
                          labelColor: AppTheme.primaryGold,
                          unselectedLabelColor: Colors.white60,
                          tabs: [
                            Tab(text: 'Scanner QR Code', icon: Icon(Icons.qr_code_scanner)),
                            Tab(text: 'Scanner le réseau', icon: Icon(Icons.wifi_find)),
                            Tab(text: 'Entrer IP manuellement', icon: Icon(Icons.keyboard)),
                          ],
                        ),
                        Expanded(
                          child: TabBarView(
                            children: [
                              // QR Scanner Tab
                              _buildQrScannerTab(setModalState),
                              // Network Scanner Tab
                              _buildNetworkScannerTab(setModalState),
                              // Manual IP Tab
                              _buildManualIpTab(setModalState),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildQrScannerTab(StateSetter setModalState) {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          Expanded(
            child: ClipRRect(
              borderRadius: BorderRadius.circular(16),
              child: MobileScanner(
                onDetect: (capture) {
                  final barcodes = capture.barcodes;
                  for (final barcode in barcodes) {
                    final value = barcode.rawValue;
                    if (value != null && value.startsWith('IBZUNG:')) {
                      final data = WiFiService.parseQrData(value);
                      if (data != null) {
                        Navigator.pop(context);
                        _joinRoomWithData(
                          data['hostIp'] as String,
                          data['port'] as int,
                          data['roomCode'] as String,
                        );
                      } else {
                        if (mounted) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(content: Text('QR Code Ibizungu invalide')),
                          );
                        }
                      }
                      break;
                    }
                  }
                },
              ),
            ),
          ),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: AppTheme.primaryGold.withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppTheme.primaryGold.withValues(alpha: 0.3)),
            ),
            child: const Row(
              children: [
                Icon(Icons.info_outline, color: AppTheme.primaryGold, size: 20),
                SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'Scannez le QR Code affiché par l\'hôte sur son écran',
                    style: TextStyle(color: Colors.white70, fontSize: 13),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildNetworkScannerTab(StateSetter setModalState) {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          // Scan Button
          ElevatedButton.icon(
            icon: _isScanningNetwork
                ? const SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(strokeWidth: 2, color: Colors.black),
                  )
                : const Icon(Icons.wifi_find),
            label: Text(_isScanningNetwork ? 'Scan en cours...' : 'Scanner le réseau local'),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.primaryGold,
              foregroundColor: Colors.black,
              padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 20),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
            onPressed: _isScanningNetwork ? null : _startNetworkScan,
          ),
          const SizedBox(height: 16),

          // Subnet indicator
          if (_selectedSubnet != null)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              decoration: BoxDecoration(
                color: Colors.blue.withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(Icons.lan, color: Colors.lightBlueAccent, size: 16),
                  const SizedBox(width: 8),
                  Text(
                    'Réseau: $_selectedSubnet.x',
                    style: const TextStyle(color: Colors.lightBlueAccent, fontSize: 12),
                  ),
                ],
              ),
            ),
          const SizedBox(height: 16),

          // Results
          Expanded(
            child: _scannedRooms.isEmpty
                ? Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          _isScanningNetwork ? Icons.hourglass_empty : Icons.search,
                          size: 48,
                          color: Colors.white30,
                        ),
                        const SizedBox(height: 12),
                        Text(
                          _isScanningNetwork
                              ? 'Recherche en cours...'
                              : 'Appuyez sur "Scanner le réseau" pour trouver des salles',
                          textAlign: TextAlign.center,
                          style: const TextStyle(color: Colors.white54),
                        ),
                      ],
                    ),
                  )
                : ListView.builder(
                    itemCount: _scannedRooms.length,
                    itemBuilder: (context, index) {
                      final room = _scannedRooms[index];
                      return Card(
                        color: Colors.white.withValues(alpha: 0.05),
                        margin: const EdgeInsets.only(bottom: 8),
                        child: ListTile(
                          leading: Container(
                            padding: const EdgeInsets.all(8),
                            decoration: BoxDecoration(
                              color: AppTheme.primaryGold.withValues(alpha: 0.2),
                              shape: BoxShape.circle,
                            ),
                            child: const Icon(
                              Icons.computer,
                              color: AppTheme.primaryGold,
                            ),
                          ),
                          title: Text(
                            room.hostName ?? 'Salle de jeu',
                            style: const TextStyle(
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                            ),
                          ),
                          subtitle: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'IP: ${room.ipAddress}:${room.port}',
                                style: const TextStyle(color: Colors.white54, fontSize: 12),
                              ),
                              if (room.roomCode != null)
                                Text(
                                  'Code: ${room.roomCode}',
                                  style: const TextStyle(color: Colors.white38, fontSize: 11),
                                ),
                            ],
                          ),
                          trailing: ElevatedButton(
                            onPressed: () {
                              Navigator.pop(context);
                              // BUG FIX: Vérifier si roomCode est null avant de rejoindre
                              if (room.roomCode == null || room.roomCode!.isEmpty) {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(content: Text('Code de salle non disponible')),
                                );
                                return;
                              }
                              _joinRoomWithData(
                                room.ipAddress,
                                room.port,
                                room.roomCode!,
                              );
                            },
                            style: ElevatedButton.styleFrom(
                              backgroundColor: AppTheme.primaryGold,
                              foregroundColor: Colors.black,
                            ),
                            child: const Text('Rejoindre'),
                          ),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  Widget _buildManualIpTab(StateSetter setModalState) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // IP Address Field
          TextField(
            controller: _ipController,
            decoration: InputDecoration(
              labelText: 'Adresse IP de l\'hôte',
              hintText: 'Ex: 192.168.1.100',
              prefixIcon: const Icon(Icons.computer),
              filled: true,
              fillColor: Colors.white.withValues(alpha: 0.05),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide.none,
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: const BorderSide(color: AppTheme.primaryGold, width: 2),
              ),
            ),
            keyboardType: const TextInputType.numberOptions(decimal: true),
          ),
          const SizedBox(height: 16),
          // Room Code Field
          TextField(
            controller: _roomCodeController,
            decoration: InputDecoration(
              labelText: 'Code de la salle',
              hintText: 'Ex: 123456',
              prefixIcon: const Icon(Icons.tag),
              filled: true,
              fillColor: Colors.white.withValues(alpha: 0.05),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide.none,
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: const BorderSide(color: AppTheme.primaryGold, width: 2),
              ),
            ),
            keyboardType: TextInputType.number,
            maxLength: 6,
            style: const TextStyle(fontSize: 20, letterSpacing: 4),
          ),
          const SizedBox(height: 8),
          // Instructions
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: AppTheme.primaryGold.withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppTheme.primaryGold.withValues(alpha: 0.3)),
            ),
            child: const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(Icons.info_outline, color: AppTheme.primaryGold, size: 20),
                    SizedBox(width: 8),
                    Text(
                      'Comment obtenir l\'IP ?',
                      style: TextStyle(
                        color: AppTheme.primaryGold,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 8),
                Text(
                  'L\'hôte peut voir son adresse IP sur son écran (ex: 192.168.1.xx)',
                  style: TextStyle(color: Colors.white70, fontSize: 13),
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),
          // Join Button
          ElevatedButton.icon(
            icon: _isLoading
                ? const SizedBox(
                    width: 24,
                    height: 24,
                    child: CircularProgressIndicator(strokeWidth: 2, color: Colors.black),
                  )
                : const Icon(Icons.login),
            label: const Text('Rejoindre la partie'),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.primaryGold,
              foregroundColor: Colors.black,
              padding: const EdgeInsets.symmetric(vertical: 16),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
            onPressed: _isLoading
                ? null
                : () {
                    final ip = _ipController.text.trim();
                    final code = _roomCodeController.text.trim();

                    if (ip.isEmpty) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('Veuillez entrer l\'adresse IP')),
                      );
                      return;
                    }

                    if (code.isEmpty || code.length != 6) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('Code de salle invalide (6 chiffres requis)')),
                      );
                      return;
                    }

                    Navigator.pop(context);
                    _joinRoomWithData(ip, 8080, code);
                  },
          ),
        ],
      ),
    );
  }

  void _startGame() {
    if (_gameService == null || _wifiService == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Erreur: Services non initialisés')),
      );
      return;
    }

    final storageService = context.read<StorageService>();
    final hasAdmin = storageService.isAdmin();
    
    if (_players.length < (hasAdmin ? 2 : 3)) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(hasAdmin ? 'Il faut au moins 2 joueurs (Mode Admin)' : 'Il faut au moins 3 joueurs')),
      );
      return;
    }

    final validPlayerCounts = [2, 3, 4, 6];
    if (!validPlayerCounts.contains(_players.length)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Nombre de joueurs invalide (3, 4 ou 6 requis)')),
      );
      return;
    }

    if (_gameMode == GameMode.groups && _players.length != 4 && _players.length != 6) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Mode Groupes: uniquement 4 ou 6 joueurs requis')),
      );
      return;
    }

    if (_gameMode == GameMode.groups) {
      _gameService!.formTeams();
    }

    final storageService = context.read<StorageService>();
    final currentBet = _betAmount.round();

    // CORRIGÉ: Vérifie le solde de TOUS les joueurs et met à jour correctement
    for (var player in _players) {
      if (player.ddkBalance < currentBet) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('${player.pseudo} n\'a pas assez de DDK (solde: ${player.ddkBalance} DDK, mise requise: $currentBet DDK)')),
        );
        return;
      }
    }

    // Met à jour le solde du joueur local UNIQUEMENT
    // Les autres soldes seront gérés par le GameService via WiFi
    final playerId = storageService.getPlayerId();
    final localPlayerIndex = _players.indexWhere((p) => p.id == playerId);
    if (localPlayerIndex >= 0) {
      final localPlayer = _players[localPlayerIndex];
      storageService.saveDdkBalance(localPlayer.ddkBalance - currentBet);
    }

    // Le GameService va gérer les mises pour tous les joueurs
    _gameService!.placeBet(currentBet);
    _gameService!.dealCards();

    // Broadcaster le début du jeu
    _wifiService!.broadcastGameStart(_gameService!.gameState!);

    Navigator.of(context).pushReplacementNamed('/game');
  }

  void _copyRoomCode() {
    if (_roomCode != null) {
      Clipboard.setData(ClipboardData(text: _roomCode!));
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Code copié !')),
      );
    }
  }

  void _copyIpAddress() {
    if (_localIp != null) {
      Clipboard.setData(ClipboardData(text: _localIp!));
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Adresse IP copiée !')),
      );
    }
  }

  Widget _buildQuickBetButton(int amount) {
    final isSelected = _betAmount.round() == amount;
    return InkWell(
      onTap: () {
        setState(() {
          _betAmount = amount.toDouble();
        });
      },
      borderRadius: BorderRadius.circular(8),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(
          color: isSelected
              ? AppTheme.primaryGold
              : AppTheme.primaryGold.withValues(alpha: 0.2),
          borderRadius: BorderRadius.circular(8),
          border: Border.all(
            color: AppTheme.primaryGold,
            width: isSelected ? 2 : 1,
          ),
        ),
        child: Text(
          '$amount',
          style: TextStyle(
            fontSize: 12,
            fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
            color: isSelected ? Colors.black : AppTheme.primaryGold,
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final wifiService = context.watch<WiFiService>();
    final isConnected = wifiService.isConnected || wifiService.isHost;

    return Scaffold(
      appBar: AppBar(
        title: Text(_isHost ? 'Créer une salle' : 'Salle de jeu'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            _wifiService?.leaveRoom();
            Navigator.of(context).pop();
          },
        ),
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              AppTheme.backgroundDark,
              AppTheme.pokerGreen,
            ],
          ),
        ),
        child: _isHost 
            ? _buildHostView() 
            : (isConnected && _roomCode != null ? _buildParticipantView() : _buildJoinView()),
      ),
    );
  }

  Widget _buildParticipantView() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(24),
      child: Column(
        children: [
          // Status Card
          Card(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                children: [
                  const Icon(Icons.check_circle, color: AppTheme.success, size: 48),
                  const SizedBox(height: 16),
                  const Text(
                    'Connecté à la salle',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Code: $_roomCode',
                    style: const TextStyle(
                      fontSize: 18,
                      color: AppTheme.primaryGold,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 2,
                    ),
                  ),
                  const SizedBox(height: 16),
                  const Text(
                    'En attente que l\'hôte démarre la partie...',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.white70, fontStyle: FontStyle.italic),
                  ),
                  const SizedBox(height: 20),
                  const LinearProgressIndicator(
                    backgroundColor: Colors.white10,
                    valueColor: AlwaysStoppedAnimation<Color>(AppTheme.primaryGold),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 32),

          // Players List
          const Text(
            'Joueurs présents',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 16),
          // Utilise les joueurs connectés du WiFiService pour être synchro
          Consumer<WiFiService>(
            builder: (context, wifi, child) {
              final players = wifi.connectedPlayers;
              return Wrap(
                spacing: 16,
                runSpacing: 16,
                alignment: WrapAlignment.center,
                children: players.map((player) {
                  return PlayerAvatar(
                    player: player,
                    size: 80,
                  );
                }).toList(),
              );
            },
          ),
          const SizedBox(height: 24),
          
          // Bet info
          if (_gameService?.gameState?.currentBet != null)
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: AppTheme.primaryGold.withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: AppTheme.primaryGold.withValues(alpha: 0.3)),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(Icons.monetization_on, color: AppTheme.primaryGold),
                  const SizedBox(width: 8),
                  Text(
                    'Mise prévue: ${_gameService!.gameState!.currentBet} DDK',
                    style: const TextStyle(color: AppTheme.primaryGold, fontWeight: FontWeight.bold),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildHostView() {
    if (_roomCode == null) {
      return _buildSetupView();
    }

    return SingleChildScrollView(
      padding: const EdgeInsets.all(24),
      child: Column(
        children: [
          // QR Code Card with IP and Room Code
          Card(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                children: [
                  const Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.wifi, color: AppTheme.primaryGold, size: 24),
                      SizedBox(width: 8),
                      Text(
                        'Connexion Wi-Fi Local',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),

                  // IP Address Display
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                    decoration: BoxDecoration(
                      color: AppTheme.primaryGold.withValues(alpha: 0.15),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: AppTheme.primaryGold.withValues(alpha: 0.3)),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(Icons.computer, color: AppTheme.primaryGold, size: 20),
                        const SizedBox(width: 8),
                        Text(
                          _localIp ?? 'Chargement...',
                          style: const TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color: AppTheme.primaryGold,
                            fontFamily: 'monospace',
                          ),
                        ),
                        const SizedBox(width: 8),
                        IconButton(
                          icon: const Icon(Icons.copy, size: 18, color: AppTheme.primaryGold),
                          onPressed: _copyIpAddress,
                          tooltip: 'Copier l\'IP',
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),

                  // QR Code with full connection data
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: FutureBuilder<String>(
                      future: _wifiService.generateHostQrData(),
                      builder: (context, snapshot) {
                        if (snapshot.hasData) {
                          return Column(
                            children: [
                              QrImageView(
                                data: snapshot.data!,
                                version: QrVersions.auto,
                                size: 180,
                              ),
                              const SizedBox(height: 8),
                              const Text(
                                'QR Code de connexion',
                                style: TextStyle(
                                  fontSize: 12,
                                  color: Colors.black54,
                                ),
                              ),
                            ],
                          );
                        }
                        return const SizedBox(
                          width: 180,
                          height: 180,
                          child: Center(child: CircularProgressIndicator()),
                        );
                      },
                    ),
                  ),
                  const SizedBox(height: 16),

                  // Room Code
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Text(
                        'Code: ',
                        style: TextStyle(fontSize: 16),
                      ),
                      Text(
                        _roomCode!,
                        style: const TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 4,
                          color: AppTheme.primaryGold,
                        ),
                      ),
                      IconButton(
                        icon: const Icon(Icons.copy, size: 20),
                        onPressed: _copyRoomCode,
                        tooltip: 'Copier le code',
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    decoration: BoxDecoration(
                      color: Colors.blue.withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: const Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.info_outline, color: Colors.lightBlueAccent, size: 16),
                        SizedBox(width: 8),
                        Flexible(
                          child: Text(
                            'Les autres joueurs peuvent scanner ce QR Code ou entrer manuellement',
                            style: TextStyle(color: Colors.lightBlueAccent, fontSize: 11),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 24),

          // Players
          const Text(
            'Joueurs',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 16),
          Wrap(
            spacing: 16,
            runSpacing: 16,
            alignment: WrapAlignment.center,
            children: _players.map((player) {
              return PlayerAvatar(
                player: player,
                size: 80,
              );
            }).toList(),
          ),
          const SizedBox(height: 16),
          Text(
            '${_players.length} / $_playerCount joueurs',
            style: const TextStyle(color: Colors.white70),
          ),
          const SizedBox(height: 16),

          // Bet Display
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
            decoration: BoxDecoration(
              color: AppTheme.primaryGold.withValues(alpha: 0.15),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppTheme.primaryGold.withValues(alpha: 0.3)),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(
                  Icons.monetization_on,
                  color: AppTheme.primaryGold,
                  size: 24,
                ),
                const SizedBox(width: 8),
                Text(
                  'Mise: ${_betAmount.round()} DDK / joueur',
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: AppTheme.primaryGold,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),

          // Start Button
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: _players.length >= 3 ? _startGame : null,
              style: ElevatedButton.styleFrom(
                backgroundColor: AppTheme.primaryGold,
                foregroundColor: Colors.black,
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              child: const Text(
                'Démarrer la partie',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSetupView() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const SizedBox(height: 40),
          const Center(
            child: Icon(
              Icons.wifi,
              size: 80,
              color: AppTheme.primaryGold,
            ),
          ),
          const SizedBox(height: 24),
          const Text(
            'Multijoueur Local',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: AppTheme.primaryGold,
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            'Créez une salle et invitez vos amis via Wi-Fi local',
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.white70),
          ),
          const SizedBox(height: 40),

          // Game Mode
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Mode de jeu',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 12),
                  RadioListTile<GameMode>(
                    title: const Text('Mode Individuel'),
                    subtitle: const Text('Chaque joueur joue seul'),
                    value: GameMode.individual,
                    groupValue: _gameMode,
                    onChanged: (value) {
                      setState(() => _gameMode = value!);
                    },
                  ),
                  RadioListTile<GameMode>(
                    title: const Text('Mode Groupes'),
                    subtitle: const Text('Équipes de 2-3 joueurs'),
                    value: GameMode.groups,
                    groupValue: _gameMode,
                    onChanged: (value) {
                      setState(() => _gameMode = value!);
                    },
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 24),

          // Player Count
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Nombre de joueurs',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 12),
                  Wrap(
                    spacing: 12,
                    children: [
                      if (context.read<StorageService>().isAdmin())
                        ChoiceChip(
                          label: const Text('2'),
                          selected: _playerCount == 2,
                          onSelected: (selected) {
                            if (selected) {
                              setState(() => _playerCount = 2);
                            }
                          },
                        ),
                      ...[4, 6].map((count) {
                      return ChoiceChip(
                        label: Text('$count'),
                        selected: _playerCount == count,
                        onSelected: (selected) {
                          if (selected) {
                            setState(() => _playerCount = count);
                          }
                        },
                      );
                    }).toList(),
                  ),
                  if (_gameMode == GameMode.individual) ...[
                    const SizedBox(height: 12),
                    Wrap(
                      spacing: 12,
                      children: [
                        ChoiceChip(
                          label: const Text('3'),
                          selected: _playerCount == 3,
                          onSelected: (selected) {
                            if (selected) {
                              setState(() => _playerCount = 3);
                            }
                          },
                        ),
                      ],
                    ),
                  ],
                  if (_gameMode == GameMode.groups) ...[
                    const SizedBox(height: 8),
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: AppTheme.primaryGold.withValues(alpha: 0.1),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: const Row(
                        children: [
                          Icon(Icons.info_outline, color: Colors.white54, size: 16),
                          SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              'Mode Groupes: uniquement 4 ou 6 joueurs',
                              style: TextStyle(color: Colors.white54, fontSize: 12),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ),
          const SizedBox(height: 24),

          // Bet Amount
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text(
                        'Mise de départ',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                        decoration: BoxDecoration(
                          color: AppTheme.primaryGold.withValues(alpha: 0.2),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: AppTheme.primaryGold),
                        ),
                        child: Text(
                          '${_betAmount.round()} DDK',
                          style: const TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: AppTheme.primaryGold,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    'Chaque joueur doit avoir ce montant pour participer',
                    style: TextStyle(color: Colors.white70, fontSize: 12),
                  ),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      const Text(
                        '50',
                        style: TextStyle(color: Colors.white54, fontSize: 12),
                      ),
                      Expanded(
                        child: Slider(
                          value: _betAmount,
                          min: _minBet,
                          max: _maxBet,
                          divisions: 49,
                          activeColor: AppTheme.primaryGold,
                          inactiveColor: AppTheme.primaryGold.withValues(alpha: 0.3),
                          onChanged: (value) {
                            setState(() {
                              _betAmount = value;
                            });
                          },
                        ),
                      ),
                      const Text(
                        '500',
                        style: TextStyle(color: Colors.white54, fontSize: 12),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      _buildQuickBetButton(50),
                      _buildQuickBetButton(100),
                      _buildQuickBetButton(200),
                      _buildQuickBetButton(300),
                      _buildQuickBetButton(500),
                    ],
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 40),

          // Create Button
          ElevatedButton.icon(
            icon: _isLoading
                ? const SizedBox(
                    width: 24,
                    height: 24,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.add),
            label: const Text('Créer une salle'),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.primaryGold,
              foregroundColor: Colors.black,
              padding: const EdgeInsets.symmetric(vertical: 16),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
            onPressed: _isLoading ? null : _createRoom,
          ),
        ],
      ),
    );
  }

  Widget _buildJoinView() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const SizedBox(height: 40),
          const Center(
            child: Icon(
              Icons.login,
              size: 80,
              color: AppTheme.primaryGold,
            ),
          ),
          const SizedBox(height: 24),
          const Text(
            'Rejoindre une partie',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: AppTheme.primaryGold,
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            'Connectez-vous à un ami via Wi-Fi local',
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.white70),
          ),
          const SizedBox(height: 40),

          // QR Scanner Button
          Card(
            child: InkWell(
              onTap: _showJoinDialog,
              borderRadius: BorderRadius.circular(12),
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: AppTheme.primaryGold.withValues(alpha: 0.15),
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(
                        Icons.qr_code_scanner,
                        size: 48,
                        color: AppTheme.primaryGold,
                      ),
                    ),
                    const SizedBox(height: 16),
                    const Text(
                      'Scanner QR Code',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'Ou entrer l\'IP manuellement',
                      style: TextStyle(color: Colors.white70, fontSize: 13),
                    ),
                  ],
                ),
              ),
            ),
          ),
          const SizedBox(height: 24),

          // Manual Entry Button
          OutlinedButton.icon(
            icon: const Icon(Icons.keyboard),
            label: const Text('Entrer IP manuellement'),
            style: OutlinedButton.styleFrom(
              foregroundColor: AppTheme.primaryGold,
              side: const BorderSide(color: AppTheme.primaryGold),
              padding: const EdgeInsets.symmetric(vertical: 16),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
            onPressed: _showJoinDialog,
          ),
          const SizedBox(height: 40),

          // Instructions
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Row(
                    children: [
                      Icon(Icons.info_outline, color: AppTheme.primaryGold),
                      SizedBox(width: 8),
                      Text(
                        'Instructions',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  const Text(
                    '1. Demandez à l\'hôte de vous montrer son QR Code\n'
                    '2. Vérifiez que vous êtes connecté au même Wi-Fi\n'
                    '3. Scannez le QR Code ou entrez l\'IP manuellement',
                    style: TextStyle(height: 1.5),
                  ),
                  const SizedBox(height: 12),
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: Colors.amber.withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: const Row(
                      children: [
                        Icon(Icons.warning_amber, color: Colors.amber, size: 16),
                        SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            'Les deux appareils doivent être sur le même réseau Wi-Fi',
                            style: TextStyle(color: Colors.amber, fontSize: 12),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
