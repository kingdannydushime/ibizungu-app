import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'models/models.dart';
import 'services/services.dart';
import 'screens/screens.dart';
import 'widgets/widgets.dart';
import 'utils/theme.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Configure la barre d'état
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
    ),
  );

  // Initialise le service de stockage
  final storageService = StorageService();
  await storageService.init();

  runApp(IbizunguApp(storageService: storageService));
}

class IbizunguApp extends StatelessWidget {
  final StorageService storageService;

  const IbizunguApp({
    super.key,
    required this.storageService,
  });

  @override
  Widget build(BuildContext context) {
    // Récupère le thème sauvegardé (défaut: sombre)
    final isDarkMode = storageService.getTheme();

    return MultiProvider(
      providers: [
        ChangeNotifierProvider.value(value: storageService),
        ChangeNotifierProvider(create: (_) => GameService()),
        ChangeNotifierProvider(create: (_) => WiFiService()),
      ],
      child: MaterialApp(
        title: 'Ibizungu',
        debugShowCheckedModeBanner: false,
        // CORRIGÉ: Utilise dynamiquement le thème selon la préférence
        theme: isDarkMode ? AppTheme.darkTheme : AppTheme.lightTheme,
        darkTheme: AppTheme.darkTheme,
        themeMode: isDarkMode ? ThemeMode.dark : ThemeMode.light,
        initialRoute: _getInitialRoute(),
        onGenerateRoute: _onGenerateRoute,
      ),
    );
  }

  String _getInitialRoute() {
    // Vérifie si l'utilisateur a déjà configuré son pseudo
    if (storageService.hasPseudo()) {
      return '/home';
    }
    return '/onboarding';
  }

  Route<dynamic>? _onGenerateRoute(RouteSettings settings) {
    switch (settings.name) {
      case '/onboarding':
        return MaterialPageRoute(
          builder: (_) => const OnboardingScreen(),
        );

      case '/home':
        return MaterialPageRoute(
          builder: (_) => const HomeScreen(),
        );

      case '/game-lobby':
        final args = settings.arguments as Map<String, dynamic>?;
        return MaterialPageRoute(
          builder: (_) => const GameLobbyScreen(),
          settings: RouteSettings(
            arguments: args,
            name: settings.name,
          ),
        );

      case '/game':
        return MaterialPageRoute(
          builder: (_) => const GameScreen(),
        );

      case '/history':
        return MaterialPageRoute(
          builder: (_) => const HistoryScreen(),
        );

      case '/about':
        return MaterialPageRoute(
          builder: (_) => const AboutScreen(),
        );

      case '/ddk-exchange':
        return MaterialPageRoute(
          builder: (_) => const DdkExchangeScreen(),
        );

      case '/ddk-transfer':
        return MaterialPageRoute(
          builder: (_) => const DdkTransferScreen(),
        );

      case '/buy-ddk':
        return MaterialPageRoute(
          builder: (_) => const BuyDdkScreen(),
        );

      case '/receive-ddk':
        return MaterialPageRoute(
          builder: (_) => const ReceiveDdkScreen(),
        );

      case '/game-end':
        final args = settings.arguments as Map<String, dynamic>?;
        return MaterialPageRoute(
          builder: (_) => GameEndScreen(
            winnerId: args?['winnerId'],
            message: args?['message'] ?? 'Partie terminée',
            mode: args?['mode'] ?? GameMode.individual,
            potAmount: args?['potAmount'] ?? 0,
          ),
        );

      case '/admin-view':
        return MaterialPageRoute(
          builder: (_) => const AdminGameView(),
        );

      case '/settings':
        return MaterialPageRoute(
          builder: (_) => const SettingsScreen(),
        );

      default:
        return MaterialPageRoute(
          builder: (_) => const HomeScreen(),
        );
    }
  }
}

/// Écran des paramètres (basique)
class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final _adminCodeController = TextEditingController();
  bool _isAdminActivated = false;

  // Code admin par défaut pour l'application
  static const String _defaultAdminCode = 'ADMIN_2026';

  @override
  void initState() {
    super.initState();
    _isAdminActivated = context.read<StorageService>().getAdminCode() != null;
  }

  @override
  void dispose() {
    _adminCodeController.dispose();
    super.dispose();
  }

  void _activateAdmin() {
    final enteredCode = _adminCodeController.text.trim();
    if (enteredCode == _defaultAdminCode) {
      context.read<StorageService>().saveAdminCode(enteredCode);
      setState(() => _isAdminActivated = true);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Mode Admin activé !'),
          backgroundColor: AppTheme.success,
        ),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Code admin incorrect'),
          backgroundColor: AppTheme.error,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final storageService = context.watch<StorageService>();
    final isDark = storageService.getTheme();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Paramètres'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              AppTheme.backgroundDark,
              AppTheme.primaryDark,
            ],
          ),
        ),
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            // Thème
            Card(
              child: SwitchListTile(
                title: const Text('Mode sombre'),
                subtitle: const Text('Activer le thème sombre'),
                secondary: Icon(
                  isDark ? Icons.dark_mode : Icons.light_mode,
                  color: AppTheme.primaryGold,
                ),
                value: isDark,
                onChanged: (value) {
                  storageService.saveTheme(value);
                },
              ),
            ),
            const SizedBox(height: 16),
            // Pseudo
            Card(
              child: ListTile(
                leading: const Icon(Icons.person, color: AppTheme.primaryGold),
                title: const Text('Pseudo'),
                subtitle: Text(storageService.getPseudo() ?? 'Non défini'),
              ),
            ),
            const SizedBox(height: 16),
            // Solde
            Card(
              child: ListTile(
                leading: const Icon(Icons.monetization_on, color: AppTheme.primaryGold),
                title: const Text('Solde DDK'),
                subtitle: Text('${storageService.getDdkBalance()} DDK'),
              ),
            ),
            const SizedBox(height: 16),
            // Code Admin
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        const Icon(Icons.admin_panel_settings, color: AppTheme.primaryGold),
                        const SizedBox(width: 12),
                        const Text(
                          'Mode Admin',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const Spacer(),
                        if (_isAdminActivated)
                          const Icon(Icons.check_circle, color: AppTheme.success),
                      ],
                    ),
                    if (_isAdminActivated) ...[
                      const SizedBox(height: 8),
                      const Text(
                        'Code: ADMIN_2026',
                        style: TextStyle(color: Colors.white70),
                      ),
                      const SizedBox(height: 12),
                      SizedBox(
                        width: double.infinity,
                        child: ElevatedButton.icon(
                          icon: const Icon(Icons.visibility),
                          label: const Text('Voir la table (Mode Admin)'),
                          onPressed: () {
                            Navigator.pushNamed(context, '/admin-view');
                          },
                        ),
                      ),
                    ] else ...[
                      const SizedBox(height: 8),
                      const Text(
                        'Entrez le code admin pour activer le mode observation',
                        style: TextStyle(color: Colors.white70, fontSize: 12),
                      ),
                      const SizedBox(height: 12),
                      Row(
                        children: [
                          Expanded(
                            child: TextField(
                              controller: _adminCodeController,
                              decoration: const InputDecoration(
                                hintText: 'Code admin',
                                isDense: true,
                              ),
                              obscureText: true,
                            ),
                          ),
                          const SizedBox(width: 12),
                          ElevatedButton(
                            onPressed: _activateAdmin,
                            child: const Text('Activer'),
                          ),
                        ],
                      ),
                    ],
                  ],
                ),
              ),
            ),
            const SizedBox(height: 32),
            // Version
            const Center(
              child: Text(
                'Version 1.0.0',
                style: TextStyle(color: Colors.white54),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Vue Admin pour observer la table sans jouer
class AdminGameView extends StatefulWidget {
  const AdminGameView({super.key});

  @override
  State<AdminGameView> createState() => _AdminGameViewState();
}

class _AdminGameViewState extends State<AdminGameView> {
  final _gameService = GameService();

  @override
  void initState() {
    super.initState();
    // Initialise une partie de démonstration pour l'admin
    _initializeDemoGame();
  }

  void _initializeDemoGame() {
    // Crée une partie fictive pour l'admin
    final demoPlayers = [
      Player(id: 'admin_obs_1', pseudo: 'Admin', ddkBalance: 0),
      Player(id: 'admin_obs_2', pseudo: 'Joueur 1', ddkBalance: 0),
      Player(id: 'admin_obs_3', pseudo: 'Joueur 2', ddkBalance: 0),
      Player(id: 'admin_obs_4', pseudo: 'Joueur 3', ddkBalance: 0),
    ];

    _gameService.createGame(
      roomCode: 'ADMIN',
      host: demoPlayers[0],
      mode: GameMode.individual,
    );
    _gameService.dealCards();
  }

  @override
  Widget build(BuildContext context) {
    final state = _gameService.gameState;

    return Scaffold(
      appBar: AppBar(
        title: const Row(
          children: [
            Icon(Icons.visibility, color: AppTheme.primaryGold),
            SizedBox(width: 8),
            Text('Mode Admin - Observation'),
          ],
        ),
        actions: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            margin: const EdgeInsets.only(right: 16),
            decoration: BoxDecoration(
              color: AppTheme.primaryGold.withValues(alpha: 0.2),
              borderRadius: BorderRadius.circular(20),
            ),
            child: const Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.visibility, size: 16, color: AppTheme.primaryGold),
                SizedBox(width: 4),
                Text(
                  'MODE OBSERVATION',
                  style: TextStyle(
                    fontSize: 10,
                    fontWeight: FontWeight.bold,
                    color: AppTheme.primaryGold,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              AppTheme.pokerGreen,
              AppTheme.feltGreen,
            ],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              // Message d'avertissement
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(12),
                margin: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.amber.withValues(alpha: 0.2),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: Colors.amber),
                ),
                child: const Row(
                  children: [
                    Icon(Icons.info, color: Colors.amber),
                    SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        'Vous observez la partie. Vous ne pouvez pas jouer.',
                        style: TextStyle(color: Colors.amber),
                      ),
                    ),
                  ],
                ),
              ),

              // Joueurs en haut
              SizedBox(
                height: 100,
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  itemCount: state?.players.length ?? 4,
                  itemBuilder: (context, index) {
                    final player = state?.players[index];
                    return Padding(
                      padding: const EdgeInsets.only(right: 16),
                      child: PlayerAvatar(
                        player: player ?? Player(id: '', pseudo: '', ddkBalance: 0),
                        isCurrentTurn: index == state?.currentPlayerIndex,
                        isAdminView: true,
                      ),
                    );
                  },
                ),
              ),

              const SizedBox(height: 16),

              // Table de jeu
              Expanded(
                child: Container(
                  margin: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: AppTheme.pokerGreenLight.withValues(alpha: 0.3),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(
                      color: AppTheme.primaryGold.withValues(alpha: 0.3),
                      width: 2,
                    ),
                  ),
                  child: Center(
                    child: state?.tableCards.isEmpty ?? true
                        ? const Text(
                            'Cartes jouées sur la table',
                            style: TextStyle(
                              color: Colors.white54,
                              fontSize: 16,
                            ),
                          )
                        : Wrap(
                            spacing: 8,
                            runSpacing: 8,
                            alignment: WrapAlignment.center,
                            children: state?.tableCards.map<Widget>((card) {
                              return CardWidget(card: card, size: 60);
                            }).toList() ?? [],
                          ),
                  ),
                ),
              ),

              // Cartes de la partie
              Container(
                height: 140,
                padding: const EdgeInsets.symmetric(horizontal: 8),
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  itemCount: state?.allCards.length ?? 24,
                  itemBuilder: (context, index) {
                    final card = state?.allCards[index];
                    return Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 4),
                      child: CardWidget(
                        card: card,
                        size: 70,
                      ),
                    );
                  },
                ),
              ),

              // Couleur forte
              if (state?.strongSuit != null)
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.star, color: AppTheme.primaryGold, size: 16),
                      const SizedBox(width: 8),
                      Text(
                        'Couleur forte: ${state!.strongSuit!.symbol}',
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
