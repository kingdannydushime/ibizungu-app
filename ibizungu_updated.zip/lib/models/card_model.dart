/// Modèle de carte pour le jeu Ibizungu
/// 24 cartes au total : As, 7, Roi, Valet, Dame, 6 pour chaque couleur (♥ ♦ ♣ ♠)

enum CardSuit {
  hearts,   // ♥ Cœurs
  diamonds, // ♦ Carreaux
  clubs,    // ♣ Trèfles
  spades,   // ♠ Piques
}

extension CardSuitExtension on CardSuit {
  String get symbol {
    switch (this) {
      case CardSuit.hearts:
        return '♥';
      case CardSuit.diamonds:
        return '♦';
      case CardSuit.clubs:
        return '♣';
      case CardSuit.spades:
        return '♠';
    }
  }
}

enum CardRank {
  six,      // 6 - 0 points
  queen,    // Dame (Q) - 2 points
  jack,     // Valet (J) - 3 points
  king,     // Roi (K) - 4 points
  seven,    // 7 - ibimari (carte principale)
  ace,      // As - ibimari (carte principale)
}

class PlayingCard {
  final CardSuit suit;
  final CardRank rank;
  final String id;

  PlayingCard({
    required this.suit,
    required this.rank,
    required this.id,
  });

  /// Hiérarchie pour gagner un pli (même couleur)
  /// As > 7 > Roi > Valet > Dame > 6
  int get hierarchy {
    switch (rank) {
      case CardRank.ace:
        return 6;
      case CardRank.seven:
        return 5;
      case CardRank.king:
        return 4;
      case CardRank.jack:
        return 3;
      case CardRank.queen:
        return 2;
      case CardRank.six:
        return 1;
    }
  }

  /// Points de la carte
  /// K = 4, J = 3, Q = 2, 6 = 0
  /// As et 7 sont des ibimari (cartes principales) mais ne donnent pas de points directement
  int get points {
    switch (rank) {
      case CardRank.king:
        return 4;
      case CardRank.jack:
        return 3;
      case CardRank.queen:
        return 2;
      case CardRank.six:
        return 0;
      case CardRank.ace:
      case CardRank.seven:
        return 0; // Ibimari mais pas de points directs
    }
  }

  /// Vérifie si c'est un ibimari (As ou 7)
  bool get isIbimari => rank == CardRank.ace || rank == CardRank.seven;

  /// Symbole de la couleur
  String get suitSymbol => suit.symbol;

  /// Nom de la carte
  String get rankName {
    switch (rank) {
      case CardRank.ace:
        return 'As';
      case CardRank.seven:
        return '7';
      case CardRank.king:
        return 'Roi';
      case CardRank.jack:
        return 'Valet';
      case CardRank.queen:
        return 'Dame';
      case CardRank.six:
        return '6';
    }
  }

  /// Nom complet de la carte
  String get fullName => '$rankName$suitSymbol';

  /// Vérifie si la carte est plus forte qu'une autre (même couleur)
  bool isStrongerThan(PlayingCard other, CardSuit? strongSuit) {
    if (suit == strongSuit && other.suit != strongSuit) {
      return true; // Cette carte est de la couleur forte
    }
    if (suit != strongSuit && other.suit == strongSuit) {
      return false; // L'autre carte est de la couleur forte
    }
    if (suit == other.suit) {
      return hierarchy > other.hierarchy;
    }
    return false;
  }

  Map<String, dynamic> toJson() => {
    'suit': suit.index,
    'rank': rank.index,
    'id': id,
  };

  factory PlayingCard.fromJson(Map<String, dynamic> json) {
    return PlayingCard(
      suit: CardSuit.values[json['suit'] as int],
      rank: CardRank.values[json['rank'] as int],
      id: json['id'] as String,
    );
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is PlayingCard &&
          runtimeType == other.runtimeType &&
          suit == other.suit &&
          rank == other.rank;

  @override
  int get hashCode => suit.hashCode ^ rank.hashCode;

  @override
  String toString() => 'PlayingCard($fullName)';
}
