import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  testWidgets('App basic test', (WidgetTester tester) async {
    await tester.pumpWidget(
      const MaterialApp(
        home: Scaffold(
          body: Center(
            child: Text('Ibizungu'),
          ),
        ),
      ),
    );

    expect(find.text('Ibizungu'), findsOneWidget);
  });
}
